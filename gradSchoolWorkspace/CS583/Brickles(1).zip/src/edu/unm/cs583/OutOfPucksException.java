package edu.unm.cs583;
import java.lang.*;

class OutOfPucksException extends Throwable {
    OutOfPucksException() { }
}
