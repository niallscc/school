package edu.unm.cs583;
interface TimeObservable {
    void tick();
}
