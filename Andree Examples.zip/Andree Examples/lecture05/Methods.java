/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Jan 29, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture05;

import java.util.Random;

import edu.unm.cs.cs251.andree.spring10.prog1.Display;

/**
 * A simple class that demonstrates how to use and write methods.
 */
public class Methods {

  /**
   * Method to draw an arbitrary number of diagonals across a display screen.
   * @param myDisplay Some initialized display from Andree's class
   * @param numDiags The number of diagonals to be drawn
   * @param incr The pixel increment by which to move pixels
   */
  public static void drawNDiagonals ( Display myDisplay, int numDiags, int incr ) {
    for ( int diagNum = 0; diagNum < numDiags; diagNum++ )
      for ( int i = myDisplay.getWidth ( ) / numDiags * diagNum; i < 400; i += incr )
	myDisplay.drawNextPixel ( i, i );
  }

  /**
   * Method to draw an arbitrary number of diagonals across a display screen and
   * returns the total number of pixels drawn by this method. This method picks
   * a random number between 1 and 10 as the pixel increment
   * @param myDisplay Some initialized display from Andree's class
   * @param numDiags The number of diagonals to be drawn
   * @return The total number of pixels drawn by this method
   */
  public static int drawNDiagonals ( Display myDisplay, int numDiags ) {
    int numPixelsDrawn = 0;
    Random rand = new Random ( );
    for ( int diagNum = 0; diagNum < numDiags; diagNum++ )
      for ( int i = myDisplay.getWidth ( ) / numDiags * diagNum; i < 400; i += rand
	  .nextInt ( 10 ) + 1 ) {
	myDisplay.drawNextPixel ( i, i );
	numPixelsDrawn++;
      }

    return numPixelsDrawn;
  }

  /**
   * The main method, this is where the program starts.
   * @param args Command line arguments, ignored in this application.
   */
  public static void main ( String[] args ) {
    Display d = new Display ( 100, 20 );
    drawNDiagonals ( d, 20, 5 );
    Display d2 = new Display ( 50, 15 );
    int nPixels = drawNDiagonals ( d2, 35 );
    System.out.println ( "Drew " + nPixels + " pixels." );
  }

}
