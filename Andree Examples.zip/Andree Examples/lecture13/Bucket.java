/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 17, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture13;

import java.util.Random;

/**
 * Container for stuff
 */
public class Bucket {

  /**
   * Keep track of the number of things we currently have in the bucket
   */
  private int numberThingsInBucket;

  /**
   * The array for the content
   */
  private Object[] content;

  /**
   * Constructor for a Bucket
   * @param capacity How many items you want to fit in the bucket
   * @throws BucketException if a bucket of negative size is attempted
   */
  public Bucket ( int capacity ) throws BucketException {
    try {
      content = new Object[capacity];
    } catch ( final NegativeArraySizeException e ) {
      throw new BucketException (
	  "You are nuts! That's not possible! I can't store a negative number of things in my bucket!" );
    }
    numberThingsInBucket = 0;
  }

  /**
   * Put something in the bucket
   * @param o What to put in the bucket
   * @throws BucketException if the bucket is already full
   */
  public void fill ( Object o ) throws BucketException {
    if ( isFull ( ) )
      throw new BucketException (
	  "Dude/tte! The bucket is already full!\n You should have checked if it was full before hand..." );
    content[numberThingsInBucket++] = o;
  }

  /**
   * The percentage level at which this bucket is currently filled
   * @return how full the bucket is (percent)
   */
  public double fillLevel ( ) {
    return numberThingsInBucket / (double) content.length * 100;
  }

  /**
   * Check if bucket is empty
   * @return <code>true</code> if bucket is empty, <code>false</code> otherwise
   */
  public boolean isEmpty ( ) {
    return numberThingsInBucket == 0;
  }

  /**
   * Check if the bucket is full
   * @return <code>true</code> if bucket is full, <code>false</code> otherwise
   */
  public boolean isFull ( ) {
    return numberThingsInBucket == content.length;
  }

  /**
   * Take a random element out of the bucket
   * @return a random element from the bucket
   * @throws BucketException if the bucket is already empty
   */
  public Object remove ( ) throws BucketException {
    if ( isEmpty ( ) )
      throw new BucketException ( "It's empty already!" );

    final Random randGen = new Random ( );
    final int randIndex = randGen.nextInt ( numberThingsInBucket );
    final Object thing = content[randIndex];
    for ( int i = randIndex + 1; i < numberThingsInBucket; i++ )
      content[i - 1] = content[i];
    numberThingsInBucket--;
    content[numberThingsInBucket] = null;
    return thing;
  }

  /**
   * Number of things currently stored in bucket
   * @return number of things currently stored in bucket
   */
  public int thingsInBucket ( ) {
    return numberThingsInBucket;
  }

  /**
   * Test our bucket.
   */
  public static void main ( String[] args ) {
    final Bucket tennisBallBucket = new Bucket ( 10 );
    for ( int i = 0; i < 10; i++ )
      tennisBallBucket.fill ( new Integer ( i ) );
    for ( int i = 0; i < 5; i++ )
      System.out.println ( tennisBallBucket.remove ( ) );
  }

}
