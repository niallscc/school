/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 17, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture13;

/**
 * Our own exception for the Bucket.
 */
public class BucketException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public BucketException ( String message ) {
    super ( message );
  }
}

