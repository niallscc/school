/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 17, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture13;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * 
 */
public class ExceptionsDemo {

  public static void main ( String[] args ) {
    // How to cause lots of exceptions
    {
      int[] x = new int[1];
      System.out.println ( "Start" );
      int numberErrors = 0;
      for ( int i = -500000000; i < 500000000; i++ ) {
	try {
	  x[i] = 10;
	} catch ( ArrayIndexOutOfBoundsException e ) {
	  // Silently ignore exception
	  numberErrors++;
	}
      }
      System.out.println ( "End, NumberErrors = " + numberErrors );
    }

    // How to avoid causing those same exceptions
    {
      int[] x = new int[1];
      System.out.println ( "Start (No exceptions)" );
      int numberErrors = 0;
      for ( int i = -500000000; i < 500000000; i++ ) {
	if ( i >= 0 && i < x.length )
	  x[i] = 10;
	else
	  numberErrors++;
      }
      System.out.println ( "End, NumberErrors = " + numberErrors );
    }

    // These examples show how we could have found the error with exceptions
    // and how we should do it (uncommented)
    //    try {
    int x = 0;
    if ( x != 0 )
      System.out.println ( 10 / x );
    else
      //    } catch ( ArithmeticException e ) {
      System.out.println ( "Did you really mean to divide by 0?" );
    //    }

    // File io Exceptions are *checked* which means that we have to do the
    // try and the catch, otherwise the compiler complains
    File f = new File ( "/Users/andree/.dummy" );
    Scanner sc = null;
    try {
      sc = new Scanner ( f );
    } catch ( FileNotFoundException e ) {
      e.printStackTrace();
    }
    while ( sc.hasNextLine ( ) )
      System.out.println ( sc.nextLine ( ) );

  }
}
