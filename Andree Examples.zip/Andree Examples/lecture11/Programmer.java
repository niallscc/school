/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture11;

/**
 * The interface that defines what a programmer is and does
 */
public interface Programmer {

  /**
   * How to write code
   * @return The program produced by the programmer while hacking
   */
  public Program hack ( );

  /**
   * Ability to compile a program
   * @param p The program to compile
   * @return true on compile success, and false on failure
   */
  public boolean compile ( Program p );

}
