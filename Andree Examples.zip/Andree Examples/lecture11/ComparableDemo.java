/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture11;

/**
 * Example showing the compareTo method in the Long class.
 */
public class ComparableDemo {

  /**
   * @param args
   */
  public static void main ( String[] args ) {
    Long l1 = new Long ( 123456789L );
    Long l2 = new Long ( 987654321L );
    System.out.println ( l1 + " " + l2 );
    System.out.println ( l2.compareTo ( l1 ) );
  }

}
