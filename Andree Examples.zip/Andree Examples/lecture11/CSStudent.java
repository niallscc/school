/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture11;

import java.awt.Color;

import edu.unm.cs.cs251.andree.spring10.lecture07.Gender;
import edu.unm.cs.cs251.andree.spring10.lecture08.Student;

/**
 * 
 */
public class CSStudent extends Student implements Programmer {

  /**
   * @param gender
   * @param eyeColor
   * @param age
   * @param name
   */
  public CSStudent ( Gender gender, Color eyeColor, int age, String name ) {
    super ( gender, eyeColor, age, name );
  }

  /**
   * @see edu.unm.cs.cs251.andree.spring10.lecture11.Programmer#compile(edu.unm.cs.cs251.andree.spring10.lecture11.Program)
   */
  @Override
  public boolean compile ( Program p ) {
    return true;
  }

  /**
   * @see edu.unm.cs.cs251.andree.spring10.lecture11.Programmer#hack()
   */
  @Override
  public Program hack ( ) {
    return new Program ( "int void(){}" );
  }

}
