/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture11;

/**
 * A computer program represented as a string
 */
public class Program {

  private String code;

  public Program ( String code ) {
    this.code = code;
  }

}
