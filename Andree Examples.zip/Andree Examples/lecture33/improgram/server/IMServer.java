/**
 * @author Andree Jacobson (andree@cs.unm.edu)
 * @version 1.0 (Nov 12, 2008)
 */
package edu.unm.cs.cs251.andree.spring10.lecture33.improgram.server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 
 */
public class IMServer {

  /** Server default port number */
  public static final short DEFAULT_PORT_NUMBER = (short) 23145;

  /** Server default log file location */
  public static final PrintStream DEFAULT_LOGFILE_LOCATION = System.out;

  /** Server version string */
  public static final String serverVersion = "0.0.1a (Nov 12, 2008)";

  /**
   * Server port number
   */
  private static short portNumber = DEFAULT_PORT_NUMBER;

  /**
   * Log output location
   */
  private static PrintStream logStream = DEFAULT_LOGFILE_LOCATION;

  /**
   * Date format to use in the log file
   */
  public static final SimpleDateFormat dateFormat = new SimpleDateFormat (
      "MM/dd/yyyy HH:mm:ss" );

  public IMServer ( String[] argv ) {
    parseAndSetCommandLineArguments ( argv );

    // Start the server socket, since we'll be listening for connections
    ServerSocket server = null;
    try {
      server = new ServerSocket ( portNumber );
    } catch ( IOException e ) {
      logPrintln ( "Unable to open socket on port " + portNumber );
      System.exit ( 1 );
    }

    // Continuously listen to the server socket for incoming connections
    logPrintln ( "Listening for connections on port " + portNumber );

    // Create the queue in which to place incoming chat requests
    ClientHandler ch = new ClientHandler ( );
    Thread t = new Thread ( ch );
    t.setDaemon ( true );
    t.start ( );

    acceptConnections ( server, ch );
  }

  /**
   * Create new games.
   * @param server The server connection socket
   */
  private void acceptConnections ( ServerSocket server, ClientHandler ch ) {

    while ( true ) {
      Socket in = null;
      try {
	in = server.accept ( );
	ch.add ( new ServerSideClient ( in ) );
      } catch ( IOException e ) {
	logPrintln ( "Unable to open incoming connection" );
      }
    }

  }

  /**
   * Make sure printing to the log file is synchronized
   * @param s message to print to log
   */
  public synchronized static void logPrint ( String s ) {
    logStream.print ( dateFormat.format ( new Date ( ) ) + ": " + s );
  }

  /**
   * Add a \n to the output of the print
   * @param s message to print to log
   */
  public static void logPrintln ( String s ) {
    logPrint ( s + "\n" );
  }

  /**
   * Starts the multithreaded IM server on the local host and takes the port
   * number as argument on the command line. If no command line port number was
   * provided, the server will listen to the default port 23145.
   * @param argv First argument on the command line is a port number in the
   *        range above 1024 but below 65535
   */
  public static void main ( String[] argv ) {

    new IMServer ( argv );
  }

  /**
   * Update the server parameters from the command line
   * @param argv Command line arguments passed from the main method
   */
  private static void parseAndSetCommandLineArguments ( String[] argv ) {

    // Check the number of arguments, if not exactly two, print the error msg
    if ( !( argv.length == 0 || argv.length == 2 ) ) {
      printUsageAndExit ( );
    }

    // Parse the port number from the command line, or use default
    if ( argv.length == 2 ) {
      try {
	portNumber = Short.parseShort ( argv[0] );
	if ( portNumber < 1024 ) {
	  portNumber = DEFAULT_PORT_NUMBER;
	}
      } catch ( NumberFormatException e ) {
	logPrintln ( "Incorrect format for port number" );
      }

      // Parse the log file location from the command line, or use default
      File logFile = new File ( argv[1] );
      try {
	logStream = new PrintStream ( logFile );
      } catch ( FileNotFoundException e ) {
	logStream = DEFAULT_LOGFILE_LOCATION;
      }
    }

    logPrintln ( "Started IM Server, Version " + serverVersion );

  }

  /**
   * Print out the usage for the command line arguments and exit
   */
  private static void printUsageAndExit ( ) {
    logPrintln ( "\njava ./IMServer [ <portNumber> <logFileLocation> ]" );
    System.exit ( 1 );
  }
}
