/**
 * @author Andree Jacobson (andree@cs.unm.edu)
 * @version 1.0 (Nov 12, 2008)
 */
package edu.unm.cs.cs251.andree.spring10.lecture33.improgram.server;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 
 */
public class ClientHandler implements Runnable {

  private static final long serialVersionUID = 1L;

  private List<ServerSideClient> clientList = Collections
      .synchronizedList ( new LinkedList<ServerSideClient> ( ) );

  private Timer timer, checkClientMsgTimer;

  /**
   * Parameter-less constructor.
   */
  public ClientHandler ( ) {
    timer = new Timer ( );
    checkClientMsgTimer = new Timer ( );
  }

  public void add ( ServerSideClient ssc ) {
    clientList.add ( ssc );
  }

  /* (non-Javadoc)
   * @see java.lang.Runnable#run()
   */
  public void run ( ) {
    checkClientMsgTimer.schedule ( new TimerTask ( ) {
      public void run ( ) {
	for ( ServerSideClient ssc : clientList ) {
	  System.out.println ( "Checking client: " + ssc.getUserName ( ) );
	  synchronized ( ssc ) {
	    String msg = ssc.receiveMessage ( );
	    if ( msg != null ) {
	      IMServer.logPrintln ( ssc.getUserName ( ) + " sent me msg: \""
		  + msg + "\"" );
	    }
	  }
	}
      }
    }, 0, 1000 );

    timer.schedule ( new TimerTask ( ) {

      @Override
      public void run ( ) {
	// Periodically iterate through myself checking for client connections
	LinkedList<ServerSideClient> removeList = new LinkedList<ServerSideClient> ( );

	for ( int i = 0; i < clientList.size ( ); i++ ) {
	  ServerSideClient c = clientList.get ( i );
	  boolean isAlive = c.sendMessage ( c.getUserName ( )
	      + " - You have been pinged!\n" );
	  if ( !isAlive ) {
	    removeList.add ( c );
	  } else {
	    IMServer.logPrintln ( "Checked: " + c );
	  }
	}

	// Remove clients that are no longer active
	for ( ServerSideClient c : removeList ) {
	  clientList.remove ( c );
	}
      }
    }, 0, 10000 );
  }

}
