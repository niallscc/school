/**
 * @author Andree Jacobson (andree@cs.unm.edu)
 * @version 1.0 (Nov 12, 2008)
 */
package edu.unm.cs.cs251.andree.spring10.lecture33.improgram.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Date;

/**
 * 
 */
public class ServerSideClient {

  private Socket clientSocket;

  private Date authDate, lastContact;
  private String userName;
  private boolean isAlive;

  private static int numUsers = 0;
  private DataOutputStream os = null;
  private DataInputStream is = null;

  public ServerSideClient ( Socket s ) {
    numUsers++;
    clientSocket = s;
    isAlive = true;
    authDate = new Date ( );
    lastContact = new Date ( );
    userName = "User" + numUsers;
    IMServer.logPrintln ( "Authenticated " + userName );
  }

  public String getUserName ( ) {
    return userName;
  }

  public boolean isAlive ( ) {
    return isAlive;
  }

  public String receiveMessage ( ) {
    String msg = null;
    try {
      if ( is == null )
	is = new DataInputStream ( clientSocket.getInputStream ( ) );
      if ( is.available ( ) > 0 ) {
	byte[] readMsg = new byte[is.available ( ) + 5];
	int bytesRead = is.read ( readMsg );
	msg = new String ( readMsg );
      }
    } catch ( IOException e ) {

    }
    return msg;
  }

  public boolean sendMessage ( String msg ) {
    try {
      if ( os == null ) {
	os = new DataOutputStream ( clientSocket.getOutputStream ( ) );
      }
      os.writeBytes ( msg );
      lastContact = new Date ( );
    } catch ( IOException e ) {
      try {
	clientSocket.close ( );
      } catch ( IOException e1 ) {
      }
      IMServer.logPrintln ( "Lost connection with " + userName + " at "
	  + IMServer.dateFormat.format ( new Date ( ) ) );
      isAlive = false;
      return false;
    }
    return true;

  }

  @Override
  public String toString ( ) {
    return userName + " autenticated since "
	+ IMServer.dateFormat.format ( authDate ) + ", Last contact: "
	+ IMServer.dateFormat.format ( lastContact );
  }
}
