/**
 * @author Andree Jacobson (andree@cs.unm.edu)
 * @version 1.0 (Nov 12, 2008)
 */
package edu.unm.cs.cs251.andree.spring10.lecture33.improgram.client;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import edu.unm.cs.cs251.andree.spring10.lecture33.improgram.server.IMServer;


/**
 * Instant messenger client, very simple I/O example for now.
 */
public class IMClient {

  /**
   * This class listens to input from server.
   */
  private class InputListener implements Runnable {

    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    public void run ( ) {
      String msg;
      // Keep running until stopped
      while ( !Thread.currentThread ( ).isInterrupted ( ) ) {
	// Relinquish some time to the CPU
	try {
	  Thread.sleep ( 100 );
	} catch ( InterruptedException e ) {

	}

	try {
	  if ( _serverbr.ready ( ) && !_serverSocket.isClosed ( ) ) {
	    msg = _serverbr.readLine ( );
	    displayArea.setText ( displayArea.getText ( ) + "\n" + "From: "
		+ msg );
	  }
	} catch ( IOException e ) {
	  // Problem with input from server, so we can break for now.
	  break;
	}
      }
      IMServer.logPrintln ( "Closed Connection" );
    }

  }

  /** Our fancy GUI frame */
  private JFrame frame;

  /** Two text areas used for input and output */
  private JTextArea inputArea, displayArea;

  /** Three buttons for sending connecting and disconnecting */
  private JButton sendButton, connectButton, disconnectButton;

  /** Temporary store of command line arguments. */
  private String[] commandLine;

  /** The listener thread, listens to input from server */
  private Thread listenThread;

  /** The buffered reader that is used to read from the server */
  private BufferedReader _serverbr;

  /** Used to write to the server */
  private DataOutputStream _serveros;

  /** Raw input stream from server */
  private DataInputStream _serveris;

  /** Server socket used to communicate with server */
  private Socket _serverSocket = null;

  /**
   * Constructor for the client
   * @param args Command line arguments should be passed in here.
   */
  public IMClient ( String[] args ) {

    commandLine = args;

    // Set up the frame
    frame = new JFrame ( );
    frame.setTitle ( "Andree's awesome chat client!" );
    frame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
    frame.setSize ( 400, 600 );

    // Create buttons for the control panel, sign on and sign off
    JPanel controlPanel = new JPanel ( );
    connectButton = new JButton ( "Sign In" );
    connectButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {

	// Set up the connection
	connectToServer ( commandLine );

	// Then start the thread that listens on the server connection
	listenThread = new Thread ( new InputListener ( ) );
	listenThread.start ( );

	connectButton.setEnabled ( false );
      }
    } );

    // Stop button 
    disconnectButton = new JButton ( "Sign Off" );
    disconnectButton.addActionListener ( new ActionListener ( ) {

      public void actionPerformed ( ActionEvent e ) {
	// Close connection, and stop listening
	boolean ans = writeToServer ( "SIGNOFF\n" );
	try {
	  listenThread.interrupt ( );
	  _serverSocket.close ( );

	  // Update Button states
	  disconnectButton.setEnabled ( false );
	  sendButton.setEnabled ( false );
	  connectButton.setEnabled ( true );

	} catch ( IOException e1 ) {
	  IMServer.logPrintln ( "Unable to close server socket" );
	}

      }
    } );
    controlPanel.add ( connectButton );
    controlPanel.add ( disconnectButton );
    frame.add ( controlPanel, BorderLayout.NORTH );

    // Pane where messages received, and sent from us are displayed
    JPanel textPanel = new JPanel ( );
    textPanel.setBorder ( BorderFactory.createEtchedBorder ( ) );
    displayArea = new JTextArea ( 29, 32 );
    JScrollPane jsp = new JScrollPane ( displayArea );
    textPanel.add ( jsp );
    jsp.setBorder ( BorderFactory.createEtchedBorder ( ) );
    displayArea.setEditable ( false );

    JPanel inputPanel = new JPanel ( );
    inputPanel.setBorder ( BorderFactory.createEtchedBorder ( ) );
    inputArea = new JTextArea ( 2, 25 );
    inputArea.setBorder ( BorderFactory.createEtchedBorder ( ) );
    inputPanel.add ( inputArea );
    sendButton = new JButton ( "Send" );
    inputPanel.add ( sendButton );
    sendButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	// Check to make sure that we have a server socket (can't send otherwise)
	if ( _serverSocket != null && _serverSocket.isBound ( ) ) {
	  String msg = inputArea.getText ( );
	  // Don't send empty messages
	  if ( msg.trim ( ).length ( ) > 0 ) {
	    // Attempt to write our message to server
	    boolean success = writeToServer ( msg + "\n" );
	    if ( success ) {
	      // Update our own display
	      inputArea.setText ( "" );
	      displayArea.setText ( displayArea.getText ( ) + "\n" + "To: "
		  + msg );
	    }
	  }
	}
      }

    } );

    // Disable buttons that can't be used until connection is established
    sendButton.setEnabled ( false );
    disconnectButton.setEnabled ( false );

    frame.add ( textPanel, BorderLayout.CENTER );
    frame.add ( inputPanel, BorderLayout.SOUTH );

    frame.setLocationRelativeTo ( null );
    frame.setVisible ( true );
  }

  private void connectToServer ( String[] args ) {

    // Better have an InetAddress
    InetAddress serverAddress = null;

    // Set some default values for the connection type
    String serverName = "localhost";
    int serverPort = IMServer.DEFAULT_PORT_NUMBER;

    // Parse the command line arguments, if any
    if ( args.length == 0 || args.length == 2 ) {
      try {
	if ( args.length == 2 ) {
	  serverName = args[0];
	  serverPort = Integer.parseInt ( args[1] );
	}
	serverAddress = InetAddress.getByName ( serverName );
      } catch ( UnknownHostException e ) {
	System.err.println ( "Sorry, can't find that server..." );
	System.exit ( 1 );
      } catch ( NumberFormatException e ) {
	System.err.println ( "The port must be formatted as a number > 1024" );
	System.exit ( 1 );
      }
    } else
      printUsage ( );

    // If we got here, it seems at least the command line parameters were correct
    // Attempt to open a connection to the server
    try {
      _serverSocket = new Socket ( serverAddress, serverPort );
      _serveris = new DataInputStream ( _serverSocket.getInputStream ( ) );
      _serverbr = new BufferedReader ( new InputStreamReader ( _serveris ) );
      _serveros = new DataOutputStream ( _serverSocket.getOutputStream ( ) );

      // Enable buttons we want to be able to click
      sendButton.setEnabled ( true );
      disconnectButton.setEnabled ( true );
    } catch ( IOException e ) {
      IMServer.logPrintln ( "Unable to open a connection to specified server." );
      System.exit ( 0 );
    }

    IMServer.logPrintln ( "Successful server sign-in" );

  }

  /**
   * Print out the usage (command line) of this program.
   */
  private void printUsage ( ) {
    System.err.println ( "java ./IMClient [<server address> <server port>]\n" );
  }

  /**
   * Try to write a message to the server
   * @param msg Message to write to the server
   * @return <code>true</code> if send was successful, <code>false</code> if not
   *         successful
   */
  private boolean writeToServer ( String msg ) {
    try {
      _serveros.writeBytes ( msg );
      IMServer.logPrintln ( "Wrote to server: " + msg );
    } catch ( IOException e ) {
      // Unable to write to server, this means we have problems, connections severed
      try {
	_serverSocket.close ( );
      } catch ( IOException e1 ) {
	// If we couldn't close, that's ok
      }
      IMServer
	  .logPrintln ( "ERROR: Server not accessible, connection severed?" );
      sendButton.setEnabled ( false );
      disconnectButton.setEnabled ( false );
      connectButton.setEnabled ( true );
      return false;
    }
    return true;
  }

  /**
   * Main method - starts our client
   * @param args
   */
  public static void main ( String[] args ) {
    IMServer.logPrintln ( "Started IM Client\n" );
    IMClient ic = new IMClient ( args );
  }

}
