/**
 * @author Andree Jacobson (andree@cs.unm.edu)
 * @version 1.0 (Nov 12, 2008)
 */
package edu.unm.cs.cs251.andree.spring10.lecture33.improgram;

/**
 * Spec for the Instant Messenger:
 * 
 *   - Client / Server Application
 *     - Server (Backed by MqSQL database):
 *       - Distribute messages between clients
 *       - Keep status of clients
 *       - Keep a list of connected clients
 *       - Authentication (UserName/Password)
 *         - Signup, Deregister, 
 * 
 * Clients should be able to perform these operations
 *   - Send and receive messages
 *     - To specific person on contact list
 *   - Log conversations
 *   - Contact list
 *     - Add / Remove contacts
 *     - Display current status of contacts
 *   - Share Files
 *   - Geewi
 *   - Maintain status
 *     - Away, Available, Invisible
 *   - Filter out unwanted buddies
 *   - 
 */
public interface JavaIMClient {

}

