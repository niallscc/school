/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture33;

import java.util.Random;

/**
 * 
 */
public class Threading {

  private final static Random randGen = new Random ( );

  public static class MyThread implements Runnable {

    private static int numThreadsCreated = 0;
    private int myId = ++numThreadsCreated;

    @Override
    public void run ( ) {
      System.out.println ( "Thread " + myId + " started" );
            try {
      	int sleepTime = 1000; // randGen.nextInt ( 5000 );
      	System.out.println ( "Thread " + myId + " goes to sleep for "
      	    + ( sleepTime / 1000.0 ) + " seconds" );
      	Thread.sleep ( sleepTime );
            } catch ( InterruptedException e ) {
      	System.err.println ( "Thread " + myId + " got woken up" );
            }

      System.out.println ( "Thread " + myId + " is done" );
    }

  }

  public static void main ( String[] args ) {
    int maxThreads = 1000;
    Thread[] threads = new Thread[maxThreads];
    for ( int i = 0; i < maxThreads; i++ ) {
      threads[i] = new Thread ( new MyThread ( ) );
    }
    for ( Thread t : threads )
      t.start ( );

  }

}
