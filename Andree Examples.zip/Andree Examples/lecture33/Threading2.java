/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture33;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 
 */
public class Threading2 {

  private final static Random randGen = new Random ( );

  private static int counter = 0;
  private static AtomicInteger atomCount = new AtomicInteger ( 0 );

  public static class MyThread implements Runnable {

    private static int numThreadsCreated = 0;
    private int myId = ++numThreadsCreated;

    @Override
    public void run ( ) {
      double sum = 0;
      System.out.println ( "Thread " + myId + " started" );
      try {
	int sleepTime = 1000; // randGen.nextInt ( 5000 );
	System.out.println ( "Thread " + myId + " goes to sleep for "
	    + ( sleepTime / 1000.0 ) + " seconds" );
	Thread.sleep ( sleepTime );
      } catch ( InterruptedException e ) {
	System.err.println ( "Thread " + myId + " got woken up" );
      }

      int incr = 1;
      if ( myId % 2 == 0 )
	incr = -1;

      for ( int i = 0; i < 100000000; i++ ) {
	sum = sum + i;
	counter = counter + incr;
	if ( myId % 2 == 0 )
	  atomCount.decrementAndGet ( );
	else
	  atomCount.incrementAndGet ( );

      }

      System.out.println ( "Thread " + myId + " is done: Sum = " + sum );
    }

  }

  public static void main ( String[] args ) {
    int maxThreads = 2;
    Thread[] threads = new Thread[maxThreads];
    for ( int i = 0; i < maxThreads; i++ ) {
      threads[i] = new Thread ( new MyThread ( ) );
    }
    for ( Thread t : threads )
      t.start ( );
    for ( Thread t : threads )
      try {
	t.join ( );
      } catch ( InterruptedException e ) {
	e.printStackTrace ( );
      }
    System.out.println ( "Counter = " + counter );
    System.out.println ( "Atomic Counter = " + atomCount );
  }

}
