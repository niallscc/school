/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Nov 13, 2009)
 */
package edu.unm.cs.cs251.andree.spring10.lecture37;

import java.io.DataInputStream;
import java.io.IOException;

/**
 * 
 */
public class FileIO {

  public static void main ( String[] args ) {

    final DataInputStream fis = new DataInputStream ( FileIO.class
	.getResourceAsStream ( "Music.mp3" ) );
    try {
      if ( fis.available ( ) > 0 ) {
	final byte[] header = new byte[6];
	fis.read ( header, 0, 6 );

	// Print out the ID#
	System.out.print ( (char) header[0] );
	System.out.print ( (char) header[1] );
	System.out.println ( (char) header[2] );
	System.out.println ( "Version: ID3v2." + header[3] + "." + header[4] );

	// Check to see if the flags are set or not
	final boolean flagA = ( header[5] & 0x80 ) == 1;
	final boolean flagB = ( header[5] & 0x40 ) == 1;
	final boolean flagC = ( header[5] & 0x20 ) == 1;
	final boolean flagD = ( header[5] & 0x10 ) == 1;

	System.out.println ( "Flag A " + flagA );
	System.out.println ( "Flag B " + flagB );
	System.out.println ( "Flag C " + flagC );
	System.out.println ( "Flag D " + flagD );

	final int size = synchSafe ( fis.readInt ( ) );
	System.out.println ( "Tag size: " + size );

      }
    } catch ( final IOException e ) {
      System.err.println ( "File read failed" );
    }

  }
  
  public static int synchSafe ( int num ) {
    int result = 0;
    result = result | ( ( num & 0x7f ) );
    result = result | ( ( num & 0x7f00 ) >> 1 );
    result = result | ( ( num & 0x7f0000 ) >> 2 );
    result = result | ( ( num & 0x7f000000 ) >> 3 );
    return result;
  }
}
