/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 21, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture37;

import javazoom.jl.decoder.JavaLayerException;

/**
 * 
 */
public class PlayMp3 {

  public static void main ( String[] args ) throws JavaLayerException {
    SuperAdvancedPlayer sap = new SuperAdvancedPlayer ( PlayMp3.class
	.getResourceAsStream ( "THX.mp3" ) );
    sap.play ( 100 );
    
  }

}
