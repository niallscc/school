/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 21, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture37;

// import bookClasses.Sound;

/**
 * 
 */
public class BookClassesPlayMP3 {

  public static void main ( String[] args ) {
    // Sound s = new Sound ( "THX.mp3" );
    // s.explore ( );

  }

}
