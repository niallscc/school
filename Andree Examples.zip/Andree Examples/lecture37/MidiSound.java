package edu.unm.cs.cs251.andree.spring10.lecture37;

import java.applet.AudioClip;
import java.io.IOException;
import java.io.InputStream;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Receiver;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.Transmitter;

/**
 * Provides play, loop, stop, reset, and close functionality to Music and Effect
 * @author Andree Jacobson ( andree@unm.edu )
 */
public class MidiSound implements AudioClip {

  protected String filename = null;
  protected Sequencer sequencer = null;

  /**
   * Constructor
   * @param filename The file to read as a Sound object
   */
  public MidiSound ( String filename ) {
    this.filename = filename;
    load ( filename );
  } // Sound

  /**
   * Closes the MIDI sequencer
   */
  public void close ( ) {
    sequencer.close ( );
  }

  /**
   * Loops the MIDI sequencer
   */
  public void loop ( ) {
    sequencer.setLoopCount ( Sequencer.LOOP_CONTINUOUSLY );
    sequencer.start ( );
  }

  /**
   * Starts the MIDI sequencer
   */
  public void play ( ) {
    sequencer.setLoopCount ( 0 );
    sequencer.start ( );
  }

  /**
   * Resets the MIDI sequencer
   */
  public void reset ( ) {
    sequencer.setTickPosition ( 0 );
  }

  /**
   * Stops the MIDI sequencer
   */
  public void stop ( ) {
    sequencer.stop ( );
  }

  /**
   * Loads a Sound object
   */
  protected void load ( String filename ) {
    try {
      final InputStream stream = MidiSound.class
	  .getResourceAsStream ( filename );

      // Get a Sequencer to play sequences of MIDI events; turn it on
      sequencer = MidiSystem.getSequencer ( );
      sequencer.open ( );

      // Get a Synthesizer for the Sequencer to send notes to
      final Synthesizer synth = MidiSystem.getSynthesizer ( );
      synth.open ( );

      // Explicitly connect the Sequencer to a Synthesizer
      final Transmitter transmitter = sequencer.getTransmitter ( );
      final Receiver receiver = synth.getReceiver ( );
      transmitter.setReceiver ( receiver );

      // Read the sequence from the file; tell the sequencer about it
      final Sequence sequence = MidiSystem.getSequence ( stream );
      sequencer.setSequence ( sequence );
    } catch ( final InvalidMidiDataException e ) {
      e.printStackTrace ( );
    } catch ( final IOException e ) {
      e.printStackTrace ( );
    } catch ( final MidiUnavailableException e ) {
      e.printStackTrace ( );
    }

  } // load

}
