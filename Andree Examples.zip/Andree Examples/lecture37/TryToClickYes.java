/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Oct 17, 2007)
 */
package edu.unm.cs.cs251.andree.spring10.lecture37;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.event.MouseInputAdapter;

public class TryToClickYes {

  /**
   * Example class that shows how to listen for buttons
   */
  private class ButtonListener implements ActionListener {
    public void actionPerformed ( ActionEvent e ) {
      System.out.println ( "Good Bye!" );
      System.exit ( 0 );
    }
  }

  /**
   * This class listens to mouse events, and is tied to the yes/no buttons in
   * the middle of the screen.
   */
  private class MouseListener extends MouseInputAdapter {
    private final JButton[] _buttons;

    public MouseListener ( JButton[] buttons ) {
      _buttons = buttons;
    }

    /**
     * The mouseEntered method takes care of the actual things that happen, as
     * it is invoked when the events we are looking for occur.
     */
    @Override
    public void mouseEntered ( MouseEvent e ) {
      final JButton b = (JButton) e.getSource ( );
      // System.out.println ( "Are you thinking of clicking: " + b.getText ( ) );
      int index = -1;

      // Only move if the button we're over is the "Yes" button
      if ( b.getText ( ).equals ( "Yes" ) ) {

	// Pick a random button as long as it's not the same as clicked
	final Random rand = new Random ( );
	do {
	  index = rand.nextInt ( _buttons.length );
	} while ( b == _buttons[index] );

	// Swap the text in the two buttons
	final String text = b.getText ( );
	b.setText ( _buttons[index].getText ( ) );
	_buttons[index].setText ( text );

	// Change the text color
	b.setForeground ( new Color ( rand.nextInt ( 255 ),
	    rand.nextInt ( 255 ), rand.nextInt ( 255 ) ) );

	// Change the font size
	final Font f = b.getFont ( );
	final int size = f.getSize ( );
	final Font newFont = new Font ( f.getName ( ), f.getStyle ( ), rand
	    .nextInt ( 50 ) );
	b.setFont ( newFont );
      }
    }
  }

  private final JFrame _mainFrame;

  /**
   * A class to make the user frustrated since they effectively can't click yes.
   */
  public TryToClickYes ( ) {

    // Set some default values to the Main Window
    _mainFrame = new JFrame ( );
    _mainFrame.setTitle ( "Try to click \"Yes\"" );
    _mainFrame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );

    /* 
     * In order for this to work, we have to make sure that the window have the 
     * keyboard focus all the time. Instead of adding listeners to all the 
     * components, we can make sure that the other components can not get the 
     * keyboard focus, by setting their focusable property to false as below.
     */
    _mainFrame.addKeyListener ( new KeyAdapter ( ) {
      @Override
      public void keyPressed ( KeyEvent e ) {
	if ( e.getKeyCode ( ) == KeyEvent.VK_Q ) {
	  System.out.println ( "You typed q for quitter!" );
	  System.exit ( 0 );
	}
      }
    } );

    // Make the window cover 75% of the screen
    final Toolkit tk = Toolkit.getDefaultToolkit ( );
    final Dimension winDim = tk.getScreenSize ( );
    _mainFrame.setSize ( new Dimension ( (int) ( winDim.width * .75 ),
	(int) ( winDim.height * .75 ) ) );

    // Create some interesting layout in the window
    final JPanel buttonPanel = new JPanel ( );
    buttonPanel.setFocusable ( false );

    final JButton quitButton = new JButton ( "Quit" );
    quitButton.addActionListener ( new ButtonListener ( ) );
    quitButton.setFocusable ( false );

    buttonPanel.add ( quitButton );
    _mainFrame.add ( buttonPanel, BorderLayout.SOUTH );

    // Create some more interesting buttons in the main area
    final JPanel centerPiece = new JPanel ( new GridLayout ( 2, 2 ) );
    centerPiece.setFocusable ( false );
    final JButton[] centerButtons = new JButton[4];
    centerButtons[0] = new JButton ( "Yes" );
    centerButtons[1] = new JButton ( "No" );
    centerButtons[2] = new JButton ( "No" );
    centerButtons[3] = new JButton ( "No" );

    // Create an instance of the mouse listener object
    final MouseListener ml = new MouseListener ( centerButtons );

    for ( final JButton b : centerButtons ) {
      centerPiece.add ( b );
      b.setPreferredSize ( new Dimension ( 200, 100 ) );

      b.addMouseListener ( ml );
      // This will also make sure that the buttons can't get pressed by tabbing
      // to them with the keyboard, since they can't get the keyboard focus.
      b.setFocusable ( false );

      // Anonymous class for action listener 
      b.addActionListener ( new ActionListener ( ) {
	public void actionPerformed ( ActionEvent e ) {
	  System.out.println ( "Why did you press: " + e.getActionCommand ( )
	      + "?" );
	  // If you want to do something with this button press, you can extract
	  // the object that received the click, and do something with it.
	  // JButton pressed = (JButton) e.getSource ( );
	  // pressed.setText ( "Pressed" );
	  // pressed.setEnabled ( false );
	}

      } );
    }
    _mainFrame.add ( centerPiece, BorderLayout.CENTER );

    // Change the LookAndFeel a bit - Remove title bars etc...
    _mainFrame.setUndecorated ( true );
    _mainFrame.getRootPane ( ).setWindowDecorationStyle ( JRootPane.FRAME );
    centerPiece.setOpaque ( false );

    // Center the window, and show it
    _mainFrame.pack ( );
    _mainFrame.setLocationRelativeTo ( null );
    _mainFrame.requestFocusInWindow ( );
    _mainFrame.setVisible ( true );
  }

  /**
   * Just start the GUI
   * @param args Command line arguments are ignored
   */
  public static void main ( String[] args ) {
    new TryToClickYes ( );
  }

}
