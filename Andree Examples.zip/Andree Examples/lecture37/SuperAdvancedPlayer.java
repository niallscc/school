/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Nov 23, 2009)
 */
package edu.unm.cs.cs251.andree.spring10.lecture37;

import java.io.InputStream;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.AudioDevice;
import javazoom.jl.player.advanced.AdvancedPlayer;

/**
 * This class is an extension of the advanced player that is provided with the
 * JLayer library in the JavaZoom jar file. In addition to providing the start
 * and stop (which actually closes the file) from the original superclass. This
 * class also provides a pausing, and restarting ability. I.e., the play()
 * method starts a paused song, and does nothing to a song that's already
 * playing. The stop() method, pauses the track, until the play() method is
 * called again. In order to completely stop the stream, you call the close()
 * method on the player object.
 */
public class SuperAdvancedPlayer extends AdvancedPlayer implements Runnable {

  /**
   * This is the thread that plays the sound
   */
  private Thread myThread = null;

  /**
   * This variable keeps track if we are playing or not.
   */
  private boolean isPlaying = false;

  /**
   * Constructor from the superclass.
   * @param stream The stream to read mp3 data from
   * @throws JavaLayerException If there are errors with the mp3 stream
   */
  public SuperAdvancedPlayer ( InputStream stream ) throws JavaLayerException {
    super ( stream );
  }

  /**
   * Shut down the stream completely.
   */
  @Override
  public synchronized void close ( ) {
    super.close ( );
  }

  /**
   * This method checks if the internal thread has been created, and if not
   * creates it. Once the thread exists, we notify all waiting processes to play
   * this sound.
   */
  @Override
  public void play ( ) {
    if ( myThread == null ) {
      myThread = new Thread ( this );
      myThread.start ( );
    }
    if ( !isPlaying ) {
      isPlaying = true;
      synchronized ( myThread ) {
	myThread.notifyAll ( );
      }
    }
  }

  /**
   * Changes the behavior of the original play method to deal with interrupts in
   * order to pause playback when the thread is interrupted.
   */
  @Override
  public boolean play ( int frames ) throws JavaLayerException {
    boolean ret = true;
    final int framesDecoded = 0;

    while ( frames-- > 0 && ret ) {
      // Check if thread has been interrupted
      if ( Thread.interrupted ( ) ) {
	// System.out.println ( "Thread waits for notification to start over" );
	// Since it was, we should pause playback, and that means suspend playing
	// until the thread is notified to start over. We also keep track of if the
	// sound is playing or not.
	synchronized ( myThread ) {
	  try {
	    isPlaying = false;
	    myThread.wait ( );
	    isPlaying = true;
	  } catch ( final InterruptedException e ) {
	    System.out.println ( "Thread wait interrupted" );
	  }
	}
      } else {
	// If we're playing, keep decoding frames.
	ret = decodeFrame ( );
      }
      // System.out.println ( "Frames decoded: " + ++framesDecoded );
    }

    // Last frame, ensure all data flushed to the audio device.
    final AudioDevice out = audio;
    if ( out != null ) {
      out.flush ( );
      synchronized ( this ) {
	complete = ( !closed );
	close ( );
      }
    }

    return ret;
  }

  /**
   * This method is required by the runnable interface and is called when the
   * thread created for this player object is started.
   */
  public void run ( ) {
    try {
      play ( Integer.MAX_VALUE );
    } catch ( final JavaLayerException e ) {
      System.out.println ( "Unable to play song" );
      System.exit ( 1 );
    }
  }

  /**
   * Interrupts the internal thread to make sure that it pauses playback.
   */
  @Override
  public void stop ( ) {
    synchronized ( this ) {
      myThread.interrupt ( );
    }
  }

}
