/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 21, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture37;

/**
 * 
 */
public class PlayMidiSound {

  /**
   * Playing a midi sound using the MidiSound class
   * @param args
   */
  public static void main ( String[] args ) {
    MidiSound ms = new MidiSound ( "tetris1.mid" );
    ms.play ( );
  }

}

