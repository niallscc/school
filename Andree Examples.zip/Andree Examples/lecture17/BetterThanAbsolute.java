/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 26, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture17;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.SpringLayout;
import javax.swing.border.BevelBorder;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * 
 */
public class BetterThanAbsolute extends SimpleGUI {

  private static final long serialVersionUID = 1L;

  public BetterThanAbsolute ( ) {
    super ( "Level is better than Absolute" );
    final JPanel p = new JPanel ( );

    SpringLayout sl = new SpringLayout ( );
    sl.putConstraint ( SpringLayout.WEST, p, 50, SpringLayout.WEST,
	getContentPane ( ) );
    sl.putConstraint ( SpringLayout.NORTH, p, 25, SpringLayout.NORTH,
	getContentPane ( ) );
    sl.putConstraint ( SpringLayout.EAST, p, -50, SpringLayout.EAST,
	getContentPane ( ) );
    sl.putConstraint ( SpringLayout.SOUTH, p, -25, SpringLayout.SOUTH,
	getContentPane ( ) );
    this.setLayout ( sl );

    p.setBorder ( BorderFactory.createBevelBorder ( BevelBorder.RAISED ) );
    p.setBackground ( Color.GREEN );
    add ( p );

  }

  /**
   * @param args
   */
  public static void main ( String[] args ) {
    new BetterThanAbsolute ( ).setVisible ( true );
  }

}
