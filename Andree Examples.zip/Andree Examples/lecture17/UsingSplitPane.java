/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 26, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture17;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JSplitPane;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * 
 */
public class UsingSplitPane extends SimpleGUI {
  private static final long serialVersionUID = 1L;

  public UsingSplitPane ( ) {
    super ( "Split?" );
    JSplitPane jsp = new JSplitPane ( );
    JPanel p1 = new JPanel ( );
    p1.setBackground ( Color.green );
    JPanel p2 = new JPanel ( );
    p2.setBackground ( Color.RED );
    jsp.add ( p1, JSplitPane.LEFT );
    jsp.add ( p2, JSplitPane.RIGHT );
    this.add ( jsp );
  }

  public static void main ( String[] args ) {
    new UsingSplitPane ( ).setVisible ( true );
  }

}
