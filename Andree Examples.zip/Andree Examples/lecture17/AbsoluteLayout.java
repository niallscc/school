/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 25, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture17;

import java.awt.Color;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * Testing to see how an absolute layout works.
 */
public class AbsoluteLayout extends SimpleGUI {
  private static final long serialVersionUID = 1L;

  public AbsoluteLayout ( ) {
    super ( "Testing an absolute layout" );

    // The null layout is "absolute"
    setLayout ( null );

    final JPanel p = new JPanel ( );

    // Then we set the bounds of the component, and it will stay right there
    p.setBounds ( 50, 25, getWidth ( ) - 100, getHeight ( ) - 75 );
    p.setBorder ( BorderFactory.createBevelBorder ( BevelBorder.RAISED ) );
    p.setBackground ( Color.GREEN );
    add ( p );

    this.addComponentListener ( new ComponentAdapter ( ) {

      /**
       * @see java.awt.event.ComponentAdapter#componentResized(java.awt.event.ComponentEvent)
       */
      @Override
      public void componentResized ( ComponentEvent e ) {
	super.componentResized ( e );
	p.setBounds ( 50, 25, getWidth ( ) - 100, getHeight ( ) - 75 );
      }

    } );

  }

  public static void main ( String[] args ) {
    new AbsoluteLayout ( ).setVisible ( true );
  }
}
