/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 26, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture17;

import java.awt.Dimension;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.SpringLayout;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * 
 */
public class TestDesktopPane extends SimpleGUI {

  private static final long serialVersionUID = 1L;
  private JDesktopPane jdp;

  public TestDesktopPane ( ) {
    super ( "JDesktop" );
    jdp = new JDesktopPane ( );
    SpringLayout sl = new SpringLayout ( );

    JInternalFrame f1 = new JInternalFrame ( );
    f1.setPreferredSize ( new Dimension ( 300, 200 ) );
    f1.setTitle ( "Frame 1" );

    JInternalFrame f2 = new JInternalFrame ( );
    f2.setPreferredSize ( new Dimension ( 300, 200 ) );
    f2.setTitle ( "Frame 2" );

    sl.putConstraint ( SpringLayout.WEST, f1, 50, SpringLayout.WEST,
	getContentPane ( ) );
    sl.putConstraint ( SpringLayout.EAST, f1, 15, SpringLayout.WEST, f2 );
    sl.putConstraint ( SpringLayout.EAST, f2, 15, SpringLayout.EAST,
	getContentPane ( ) );
    jdp.setLayout ( sl );

    jdp.add ( f1 );
    jdp.add ( f2 );

    this.add ( jdp );
    f1.setVisible ( true );
    f2.setVisible ( true );
  }

  public static void main ( String[] args ) {
    new TestDesktopPane ( ).setVisible ( true );
  }

}
