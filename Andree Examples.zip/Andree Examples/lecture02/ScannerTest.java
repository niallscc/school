/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Jan 22, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture02;

import java.util.Scanner;

/**
 * Simple example from the class slides. Shows how to read integer input from
 * the keyboard and make a simple loop.
 */
public class ScannerTest {
  public static void main ( String[] args ) {
    Scanner keyboard = new Scanner ( System.in );
    int num = 0;
    do {
      System.out.print ( "Enter a number: " );
      num = keyboard.nextInt ( );
    } while ( num != 0 );
  }
}
