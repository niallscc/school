/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 1, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture18;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * Shows how to react to mouse input and draw custom things on a panel.
 */
public class UsingGraphics extends SimpleGUI {

  /**
   * Panel that we control drawing of.
   */
  private class DrawPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    @Override
    public void paintComponent ( Graphics g ) {
      // clears the panel before every repaint
      super.paintComponent ( g );

      // Record current mouse position
      final Point p = this.getMousePosition ( );

      // Draw a transformed image at last clicked location
      final Graphics2D g2d = (Graphics2D) g;
      if ( lastClicked != null ) {

	// Note transforms are additive, hence the scaling of the
	// width and height in the translate formula
	final AffineTransform at = new AffineTransform ( );
	at.translate ( lastClicked.x - theImage.getWidth ( ) / 8, lastClicked.y
	    - theImage.getHeight ( ) / 8 );
	at.scale ( .25, .25 );

	// Finally draw the image
	g2d.drawRenderedImage ( theImage, at );
      }

      // Draw cross hair around the mouse pointer
      g.setColor ( Color.RED );
      if ( p != null ) {
	g.drawLine ( p.x - 5, p.y, p.x + 5, p.y );
	g.drawLine ( p.x, p.y - 5, p.x, p.y + 5 );
      }
    }
  }

  private static final long serialVersionUID = 1L;
  /** Represents the image to draw on a mouse click. */
  private BufferedImage theImage;

  { // Initializer block is executed *before* any constructor
    try {
      theImage = ImageIO.read ( new URL (
	  "http://glaiklove.files.wordpress.com/2009/10/lolcat.jpg" ) );
    } catch ( final MalformedURLException e ) {
      System.err.println ( "That's not a valid URL" );
      System.exit ( 1 );
    } catch ( final IOException e ) {
      System.err.println ( "Can't open that file" );
      System.exit ( 1 );
    }
  }

  /** Record last clicked location here. */
  private Point lastClicked = null;

  /** The panel to draw on. */
  private final DrawPanel drawPanel;

  /** Where we will report the x coordinate. */
  private final JTextField xPos;

  /** Where we will report the y coordinate. */
  private final JTextField yPos;

  /** Constructor for our awesome gui! */
  public UsingGraphics ( ) {
    super ( "Graphics methods in use" );

    drawPanel = new DrawPanel ( );
    this.add ( drawPanel, BorderLayout.CENTER );

    // Make the panel do something when clicked
    drawPanel.addMouseListener ( new MouseAdapter ( ) {
      @Override
      public void mouseClicked ( MouseEvent e ) {
	lastClicked = e.getPoint ( );
	drawPanel.repaint ( );
      }
    } );

    // Update coordinate when the mouse moves
    drawPanel.addMouseMotionListener ( new MouseMotionListener ( ) {

      @Override
      public void mouseDragged ( MouseEvent e ) {
	updateMousePosition ( e );
      }

      @Override
      public void mouseMoved ( MouseEvent e ) {
	updateMousePosition ( e );
      }

      public void updateMousePosition ( MouseEvent e ) {
	final Point p = e.getPoint ( );
	xPos.setText ( new Integer ( p.x ).toString ( ) );
	yPos.setText ( new Integer ( p.y ).toString ( ) );
	drawPanel.repaint ( );
      }
    } );

    // Set up the GUI
    final JPanel statusBar = new JPanel ( );
    final JLabel xPosLab = new JLabel ( "xCoord:" );
    xPos = new JTextField ( );
    xPos.setColumns ( 4 );
    xPos.setEditable ( false );
    statusBar.add ( xPosLab );
    statusBar.add ( xPos );
    final JLabel yPosLab = new JLabel ( "yCoord:" );
    yPos = new JTextField ( );
    yPos.setColumns ( 4 );
    yPos.setEditable ( false );
    statusBar.add ( yPosLab );
    statusBar.add ( yPos );
    this.add ( statusBar, BorderLayout.NORTH );
  }

  public static void main ( String[] args ) {
    new UsingGraphics ( ).setVisible ( true );
  }

}
