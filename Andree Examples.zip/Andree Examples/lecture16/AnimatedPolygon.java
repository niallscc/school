/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 20, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture16;

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * Example that shows how to use drawing methods to do a nice moving polygon
 * animation.
 */
public class AnimatedPolygon extends SimpleGUI {

  /**
   * Class used to draw the polygons on a JPanel
   */
  private class DrawingPanel extends JPanel {

    /** To shut the compiler up. */
    private static final long serialVersionUID = 1L;

    /**
     * Draw the polygons every time the frame is repainted
     * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
     */
    @Override
    public void paintComponent ( Graphics g ) {
      g.clearRect ( 0, 0, getWidth ( ), getHeight ( ) );
      ( (Graphics2D) g ).setRenderingHint ( RenderingHints.KEY_ANTIALIASING,
	  RenderingHints.VALUE_ANTIALIAS_ON );
      // Make sure it looks good if we are filling the polygons
      if ( FILL ) {
	( (Graphics2D) g ).setComposite ( AlphaComposite.SrcIn );
      }

      // Draw all polygons
      for ( Shape s : shapes ) {
	g.setColor ( ( (WarpingPolygon) s ).myColor );

	// And draw an outline if the polygon is filled.
	if ( FILL ) {
	  ( (Graphics2D) g ).fill ( s );
	  g.setColor ( Color.BLACK );
	}
	( (Graphics2D) g ).draw ( s );

      }
    }
  }

  /**
   * Class that represents a constantly warping polygon.
   */
  private class WarpingPolygon extends Polygon {

    /** To shut the compiler up. */
    private static final long serialVersionUID = 1L;

    /** Movement patterns in x and y direction for each point on the polygon. */
    private int[] xdeltas, ydeltas;

    /** The color of this polygon (randomly assigned in constructor. */
    private Color myColor;

    /**
     * Create a polygon just like {@link Polygon#Polygon(int[], int[], int)}
     * except for the number of points in the polygon is the number of points
     * int the arrays that are passed in.
     * @param xPoints X coordinates for the points on this polygon
     * @param yPoints Y coordinates for the points on this polygon
     */
    public WarpingPolygon ( int[] xPoints, int[] yPoints ) {
      super ( xPoints, yPoints, xPoints.length );

      // Randomly define the initial deltas for all points in polygon
      xdeltas = new int[NUM_POINTS];
      ydeltas = new int[NUM_POINTS];
      for ( int i = 0; i < xdeltas.length; i++ ) {
	xdeltas[i] = randGen.nextInt ( 10 ) - 5;
	ydeltas[i] = randGen.nextInt ( 10 ) - 5;
      }

      // Set each polygon to a random color
      myColor = new Color ( randGen.nextInt ( 256 ), randGen.nextInt ( 256 ),
	  randGen.nextInt ( 256 ) );
    }

    /**
     * Move polygon to next warped state.
     */
    public void warp ( ) {
      // Move each point according to the delta defined in the constructor, but 
      // in case the new coordinate would fall outside the rectangle, change the 
      // direction of the movement, causing the points on the polygon to bounce
      // against the walls.
      for ( int i = 0; i < NUM_POINTS; i++ ) {

	// Check in case window was resized so that we never have points outside
	// the window.
	if ( xpoints[i] > drawPanel.getWidth ( ) )
	  xpoints[i] = drawPanel.getWidth ( ) - 1;
	if ( xpoints[i] < 0 )
	  xpoints[i] = 0;
	if ( ypoints[i] > drawPanel.getHeight ( ) )
	  ypoints[i] = drawPanel.getHeight ( ) - 1;
	if ( ypoints[i] < 0 )
	  ypoints[i] = 0;

	// First check new x coordinate
	if ( !drawPanel.contains ( xpoints[i] + xdeltas[i], ypoints[i] ) ) {
	  xdeltas[i] = -xdeltas[i] + randGen.nextInt ( 4 ) - 2;
	}
	// Then they the new ycoordinate
	if ( !drawPanel.contains ( xpoints[i], ypoints[i] + ydeltas[i] ) ) {
	  ydeltas[i] = -ydeltas[i] + randGen.nextInt ( 4 ) - 2;
	}

	// Make sure all points are moving, if they go to 0 they will not move.
	if ( xdeltas[i] == 0 ) {
	  xdeltas[i] = 1;
	}
	if ( ydeltas[i] == 0 ) {
	  ydeltas[i] = 1;
	}

	// Finally set the new coordinate
	xpoints[i] += xdeltas[i];
	ypoints[i] += ydeltas[i];
      }
    }
  }

  /** Total number of polygons to draw. */
  public static final int NUM_POLYGONS = 1;

  /** Total number of points on each polygon. */
  public static final int NUM_POINTS = 50;

  /** Draw filled polygons or just outlines? */
  public static final boolean FILL = true;

  /** A random number generator to use throughout. */
  private final Random randGen = new Random ( );

  /** To shut the compiler up. */
  private static final long serialVersionUID = 1L;

  /** List of shapes to draw. These would be our polygons. */
  private ArrayList<Shape> shapes = new ArrayList<Shape> ( );

  /**
   * Timer that controls the animation
   */
  private Timer timer;

  /**
   * Instance variable for the drawing panel so that it is accessible from other
   * parts of the program.
   */
  private DrawingPanel drawPanel;

  /**
   * Constructor for the whole example.
   */
  public AnimatedPolygon ( ) {
    super ( "Polygon Animation" );
    this.add ( drawPanel = new DrawingPanel ( ), BorderLayout.CENTER );
    createPolygons ( );

    // Set up the timer to update the screen every so often, and when that
    // happens, call the Warp method on each polygon in the list and repaint
    timer = new Timer ( 500, new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	for ( int i = 0; i < shapes.size ( ); i++ ) {
	  WarpingPolygon p = (WarpingPolygon) shapes.get ( i );
	  p.warp ( );
	}
	drawPanel.repaint ( );
      }
    } );

    JPanel controlPanel = new JPanel ( );
    JSlider slider = new JSlider ( );
    slider.setMinimum ( 0 );
    slider.setMaximum ( 1000 );
    slider.setPreferredSize ( new Dimension ( this.getWidth ( ), 50 ) );
    slider.setValue ( 500 );
    slider.addChangeListener ( new ChangeListener ( ) {
      @Override
      public void stateChanged ( ChangeEvent e ) {
	JSlider s = (JSlider)e.getSource();
	timer.setDelay ( s.getValue ( ) );
      }
    } );
    controlPanel.add ( slider );
    add ( controlPanel, BorderLayout.SOUTH );

  }

  /**
   * Let the action commence!
   */
  public void startAnimation ( ) {
    timer.start ( );
  }

  /**
   * Create the initial polygons.
   */
  private void createPolygons ( ) {
    // Create the polygons by randomly assigning starting points.
    int[] xs = new int[NUM_POINTS];
    int[] ys = new int[NUM_POINTS];
    for ( int p = 0; p < NUM_POLYGONS; p++ ) {
      for ( int n = 0; n < NUM_POINTS; n++ ) {
	xs[n] = randGen.nextInt ( getWidth ( ) );
	ys[n] = randGen.nextInt ( getHeight ( ) );
      }

      // Add the polygon to the list of shapes to draw
      shapes.add ( new WarpingPolygon ( xs, ys ) );
    }
  }

  /**
   * Main method, this is where the program starts.
   * @param args Command line arguments, not used in this application.
   */
  public static void main ( String[] args ) {
    AnimatedPolygon ap = new AnimatedPolygon ( );
    ap.setVisible ( true );
    ap.startAnimation ( );
  }

}
