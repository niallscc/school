/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 24, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture16;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JPanel;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

public class DrawThings extends SimpleGUI implements ActionListener {

  private static final long serialVersionUID = 1L;

  private enum DrawFunction {
    SQUARE, CIRCLE, LINE;
  }

  private JButton[] buttons = new JButton[DrawFunction.values ( ).length];

  public DrawThings ( ) {
    super ( "Draw Things" );
    add ( panel, BorderLayout.CENTER );
    JPanel controlPanel = new JPanel ( );
    for ( DrawFunction df : DrawFunction.values ( ) ) {
      buttons[df.ordinal ( )] = new JButton ( df.toString ( ) );
      buttons[df.ordinal ( )].addActionListener ( this );
      controlPanel.add ( buttons[df.ordinal ( )] );
    }
    add ( controlPanel, BorderLayout.SOUTH );
  }

  /** Keep track of shapes drawn */
  private ArrayList<Shape> shapeList = new ArrayList<Shape> ( );

  private DrawPanel panel = new DrawPanel ( );

  private class DrawPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    public void paintComponent ( Graphics g ) {
      // Draw all shapes in list
      g.setColor ( Color.BLACK );
      for ( Shape s : shapeList ) {
	( (Graphics2D) g ).draw ( s );
      }
    }
  }

  public static void main ( String[] args ) {
    new DrawThings ( ).setVisible ( true );

  }

  private Random randGen = new Random ( );

  /**
   * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
   */
  @Override
  public void actionPerformed ( ActionEvent e ) {
    int width = randGen.nextInt ( panel.getWidth ( ) / 2 );
    int height = randGen.nextInt ( panel.getHeight ( ) / 2 );
    int size = Math.min ( width, height );
    int startX = randGen.nextInt ( panel.getWidth ( ) - size );
    int startY = randGen.nextInt ( panel.getHeight ( ) - size );
    switch ( DrawFunction.valueOf ( e.getActionCommand ( ) ) ) {
      case CIRCLE:
	shapeList.add ( new Ellipse2D.Double ( startX, startY, size, size ) );
	break;
      case LINE:
	shapeList.add ( new Line2D.Double ( startX, startY, startX + width,
	    startY + height ) );
	break;
      case SQUARE:
	shapeList.add ( new Rectangle2D.Double ( startX, startY, size, size ) );
	break;
    }
    panel.repaint ( );
  }
}
