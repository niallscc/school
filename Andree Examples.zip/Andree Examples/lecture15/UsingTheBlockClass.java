/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 22, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture15;

import edu.unm.cs.cs251.andree.spring10.prog2.Block;

/**
 * Example of how to use the block class in the 2nd assignment. (Note this is
 * giving away a fair chunk of the assignment.)
 */
public class UsingTheBlockClass {

  public static void main ( String[] args ) {
    Block[][] blocks = new Block[10][10];
    for ( int i = 0; i < blocks.length; i++ ) {
      for ( int j = 0; j < blocks[i].length; j++ ) {
	blocks[i][j] = new Block ( ( i + j ) % 2 == 0 ? Block.Type.PRESENT
	    : Block.Type.MISSING );
      }
    }

    for ( Block[] line : blocks ) {
      for ( Block b : line ) {
	System.out.print ( b );
      }
      System.out.print ( "\n" );
    }
  }

}
