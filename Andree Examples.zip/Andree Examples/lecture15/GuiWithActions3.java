/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 22, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture15;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * Third way of getting to the point where a button does something. This time
 * we're using what's called an anonymous class completely implemented in the
 * method argument to addActionListener. Weird? Maybe, but for small action
 * listeners it's pretty much an ideal solution.
 */
public class GuiWithActions3 extends SimpleGUI {

  private static final long serialVersionUID = 1L;

  /**
   * Constructor.
   */
  public GuiWithActions3 ( ) {
    super ( "Look Ma, I can do it!" );
    JPanel controlPanel = new JPanel ( );
    JButton quit = new JButton ( "Quit" );
    quit.addActionListener ( new ActionListener ( ) {
      @Override
      public void actionPerformed ( ActionEvent e ) {
	int answer = JOptionPane.showConfirmDialog ( GuiWithActions3.this,
	    "Are you sure you want to quit?", "Really quit?",
	    JOptionPane.YES_NO_OPTION );
	if ( answer == JOptionPane.YES_OPTION ) {
	  System.exit ( 0 );
	}
      }
    } );
    controlPanel.add ( quit );
    this.add ( controlPanel, BorderLayout.SOUTH );
  }

  /**
   * Main method.
   * @param args Command line arguments, not used in this application.
   */
  public static void main ( String[] args ) {
    new GuiWithActions3 ( ).setVisible ( true );
  }

}
