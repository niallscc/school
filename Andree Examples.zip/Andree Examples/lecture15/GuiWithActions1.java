/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 22, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture15;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * First example showing how to make a button do something. This version has the
 * main class implementing the ActionListener interface. This is a common way of
 * doing this, and it gives the actionPerformed method access to the same object
 * by just referring to it by "this" which is sometimes very convenient.
 */
public class GuiWithActions1 extends SimpleGUI implements ActionListener {

  private static final long serialVersionUID = 1L;

  /**
   * Constructor.
   */
  public GuiWithActions1 ( ) {
    super ( "Look Ma, I can do it!" );
    JPanel controlPanel = new JPanel ( );

    // Add one button, and link a listener to it
    JButton quit = new JButton ( "Quit" );
    quit.addActionListener ( this );

    // Add a second button and use the same listener for it
    JButton move = new JButton ( "Move" );
    move.addActionListener ( this );

    controlPanel.add ( move );
    controlPanel.add ( quit );
    this.add ( controlPanel, BorderLayout.SOUTH );
  }

  /**
   * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
   */
  @Override
  public void actionPerformed ( ActionEvent e ) {

    // Action command can be set for a component by the setActionCommand method
    // System.out.println ( e.getActionCommand ( ) );

    // The getSource method gives you a reference to the object that caused the
    // event.
    // System.out.println ( e.getSource ( ) );

    // So this is one way to distinguish which object the event came from
    if ( e.getActionCommand ( ).equals ( "Quit" ) ) {
      int answer = JOptionPane.showConfirmDialog ( this,
	  "Are you sure you want to quit?", "Really quit?",
	  JOptionPane.YES_NO_OPTION );
      if ( answer == JOptionPane.YES_OPTION ) {
	System.exit ( 0 );
      }
    } else if ( e.getActionCommand ( ).equals ( "Move" ) ) {
      // Ignored for now
    }
  }

  /**
   * Main method
   * @param args Command line arguments, ignored in this application.
   */
  public static void main ( String[] args ) {
    new GuiWithActions1 ( ).setVisible ( true );
  }

}
