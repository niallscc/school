/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 22, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture15;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * In a similar fashion to example 1, this application does the same thing, but
 * implements the action listener in a separate inner nested class of the outer
 * class.
 */
public class GuiWithActions2 extends SimpleGUI {

  /**
   * Separate class that only provides the listener for actions
   */
  private class MyActionListener implements ActionListener {

    /**
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    @Override
    public void actionPerformed ( ActionEvent e ) {
      // Note that the GuiWithActions2.this seems a little weird as it really
      // should be static reference, but in this case only expands the scope 
      // to the outer class.
      int answer = JOptionPane.showConfirmDialog ( GuiWithActions2.this,
	  "Are you sure you want to quit?", "Really quit?",
	  JOptionPane.YES_NO_OPTION );
      if ( answer == JOptionPane.YES_OPTION ) {
	System.exit ( 0 );
      }
    }
  }

  private static final long serialVersionUID = 1L;

  /**
   * Constructor.
   */
  public GuiWithActions2 ( ) {
    super ( "Look Ma, I can do it!" );
    JPanel controlPanel = new JPanel ( );
    JButton quit = new JButton ( "Quit" );
    quit.addActionListener ( new MyActionListener ( ) );
    controlPanel.add ( quit );
    this.add ( controlPanel, BorderLayout.SOUTH );
  }

  /**
   * Main method.
   * @param args Command line arguments, not used in this application.
   */
  public static void main ( String[] args ) {
    new GuiWithActions2 ( ).setVisible ( true );
  }

}
