/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 23, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture38;

/**
 * Shows how to use recursive backtracking to generate permutations of words.
 */
public class WordPermute {

  public static void printPermutations ( String s, String unused ) {
    if ( unused.length ( ) == 0 ) {
      System.out.println ( "Permutation: " + s );
    } else {

      if ( s.length ( ) >= 3 )
	System.out.println ( "Permutation: " + s );

      for ( int i = 0; i < unused.length ( ); i++ ) {
	char ch = unused.charAt ( i );
	s = s + ch;
	String newUnused = unused.substring ( 0, i )
	    + unused.substring ( i + 1 );
	// System.out.println ( newUnused );
	printPermutations ( s, newUnused );
	s = s.substring ( 0, s.length ( ) - 1 );
      }

    }
  }

  public static void printPermutations ( String s ) {
    String unused = s;
    printPermutations ( "", unused );
  }

  public static void main ( String[] args ) {
    String str = "final";
    printPermutations ( str );
  }

}
