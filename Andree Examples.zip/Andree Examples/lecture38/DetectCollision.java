/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 23, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture38;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * 
 */
public class DetectCollision extends SimpleGUI {

  private static final long serialVersionUID = 1L;
  private List<Shape> shapes = new ArrayList<Shape> ( );

  public DetectCollision ( ) {
    super ( "Check intersects" );
    Shape s1 = new Rectangle2D.Double ( 100, 100, 50, 75 );
    Shape s2 = new Ellipse2D.Double ( 149, 125, 26, 26 );
    shapes.add ( s1 );
    shapes.add ( s2 );
    this.add ( new DrawingPanel ( ), BorderLayout.CENTER );
  }

  private class DrawingPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    public DrawingPanel ( ) {
      this.addMouseMotionListener ( new MouseAdapter ( ) {
	public void mouseMoved ( MouseEvent e ) {
	  Shape s = shapes.get ( shapes.size ( ) - 1 );
	  if ( s instanceof Ellipse2D.Double ) {
	    ( (Ellipse2D.Double) s ).x = e.getPoint ( ).x
		- s.getBounds2D ( ).getWidth ( ) / 2;
	    ( (Ellipse2D.Double) s ).y = e.getPoint ( ).y
		- s.getBounds2D ( ).getHeight ( ) / 2;
	    repaint ( );
	  }
	}
      } );
    }

    public void paintComponent ( Graphics g ) {
      super.paintComponent ( g );
      Shape lastShape = null;
      for ( Shape s : shapes ) {
	if ( lastShape != null ) {
	  if ( lastShape.intersects ( s.getBounds2D ( ) ) )
	    g.setColor ( Color.RED );
	  else
	    g.setColor ( Color.BLACK );
	}
	( (Graphics2D) g ).draw ( s );
	lastShape = s;
      }
      g.setColor ( Color.green );
      ( (Graphics2D) g ).draw ( lastShape.getBounds2D ( ) );
    }
  }

  public static void main ( String[] args ) {
    new DetectCollision ( ).setVisible ( true );
  }

}
