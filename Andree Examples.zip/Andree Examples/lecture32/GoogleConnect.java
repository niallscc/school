/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 23, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture32;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * 
 */
public class GoogleConnect {

  /**
   * This method is used to ask a question of google. Please do not modify this
   * method, only use it to download questions as you need it.
   * @param question The question that you want to send to google
   * @return The html/xml code that the google search returns
   */
  public static String askQuestion ( String question ) {

    // Needed to set up the Internet connection
    InetAddress address = null;
    Socket server = null;

    // Needed to read and write data from and to the server
    DataOutputStream dos = null;
    DataInputStream dis = null;

    // Set up the state of the socket and create all variables needed
    // also make sure that the connection was successful.
    try {
      address = InetAddress.getByName ( "www.google.com" );
      server = new Socket ( address, 80 );
      dis = new DataInputStream ( server.getInputStream ( ) );
      dos = new DataOutputStream ( server.getOutputStream ( ) );
    } catch ( UnknownHostException e ) {
      throw new RuntimeException ( e );
    } catch ( IOException e ) {
      throw new RuntimeException ( e );
    }

    // Send the get command for the page on the server, correctly formatted
    question = question.replaceAll ( " ", "+" );
    try {
      String cmd = "GET /search?hl=en&source=hp&q=%22"
	  + question
	  + "%22&btnG=Google+Search&aq=f&aqi=g3g-c1g6&aql=&oq=&gs_rfai= HTTP/1.1\r\n"
	  + "Host: www.google.com\r\n"
	  + "Connection: close\r\n"
	  + "Accept: application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,*/*;q=0.5\r\n\n\n";
      dos.writeBytes ( cmd );
    } catch ( IOException e ) {
      throw new RuntimeException ( e );
    }

    // Read bytes into buffer from the stream until the end of file has been detected
    StringBuffer sbuf = new StringBuffer ( );
    try {
      int len = 0;
      byte bytes[] = new byte[1024];

      // Fill a buffer repeatedly until the server closes connection
      while ( ( len = dis.read ( bytes ) ) != -1 )
	sbuf.append ( new String ( bytes, 0, len ) );

      // Then close the server connection and exit
      server.close ( );

    } catch ( IOException e ) {
      throw new RuntimeException ( e );
    }

    try {
      // Sleep a little so we don't hit the server too often.
      // We don't want google to block us :)
      Thread.sleep ( 1000 );
    } catch ( InterruptedException e ) {
      // Sleep interrupted, not too much to bicker about
    }
    // Return the portion of the server response that is actually the html data
    return sbuf.substring ( sbuf.indexOf ( "\r\n\r\n" ) + 4 ).toString ( );
  }

  public static void main ( String[] argv ) {
    String data = askQuestion ( "How tall am I?" );
    System.out.println ( data );
  }
}
