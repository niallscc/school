/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 10, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture10;

/**
 * 
 */
public class Calf extends Cow {

}
