/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 10, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture10;

/**
 * An animal that lives in the wild.
 */
public abstract class WildAnimal extends Animal {

  /**
   * Constructor that must be called from subclass of WildAnimal.
   * @param sound The sound that the wild animal makes
   */
  public WildAnimal ( String sound ) {
    super ( sound );
  }

}
