/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 10, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture10;

/**
 * Concrete implementation of a wild animal
 */
public class Wolf extends WildAnimal {

  /**
   * Constructor that makes a howling wolf
   */
  public Wolf ( ) {
    super ( "Howl" );
  }

  /**
   * The wolf can only eat farm animals
   * @see Animal#eat(Object)
   */
  @Override
  public void eat ( Object x ) {
    if ( x instanceof FarmAnimal )
      System.out.println ( "Yum!" );
    else
      System.out.println ( "Yuck!" );
  }
}
