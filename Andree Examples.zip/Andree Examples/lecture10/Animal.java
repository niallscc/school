/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 10, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture10;

/**
 * The abstract definition of the Animal class makes it impossible to create an
 * instance of the class Animal. If you try it, you will get an error like in
 * the main method below.
 */
public abstract class Animal {

  /**
   * Instance variable representing the sound that this animal makes.
   */
  private final String sound;

  /**
   * Constructor that can only be called from subclasses of Animal.
   * @param sound The sound that this animal makes
   */
  public Animal ( String sound ) {
    this.sound = sound;
  }

  /**
   * The abstract method eat is defined here, saying that every concrete
   * subclass of Animal *must* define the eat method, or inherit a concrete
   * implementation from some other class.
   * @param x Is the object to eat
   */
  public abstract void eat ( Object x );

  /**
   * This is a concrete implementation of the getSound method, and note that I
   * can refer to the variable sound, that still haven't gotten a value, not
   * until the Animal constructor is called from a subclass of Animal.
   * @return The sound that this animal makes
   */
  public String getSound ( ) {
    return sound;
  }

  /**
   * A testing main method that currently does not do anything.
   * @param args Command line arguments - not used in this application.
   */
  public static void main ( String[] args ) {
    // The following line generates the compiler error:
    //   - Can not instantiate the class Animal
    // that's why it's commented out.
    // Animal a = new Animal ( "xxx" );
  }

}
