/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 10, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture10;

import java.util.LinkedList;

/**
 * This is a sample class written to try to explain how the "this" keyword
 * works.
 */
public class Thing {

  /**
   * An instance variable to keep track of the serial number for this particular
   * object instance. It's declared final so that it can't be changed once
   * assigned an initial value in the constructor.
   */
  private final int mySerial;

  /**
   * This static field (called a class variable - which is different from an
   * instance variable) is the serial number counter that we'll use to keep
   * track of how many instances of this class has been created. Since it's
   * declared static, it belongs to the class, and all instances of this class
   * share a single copy of this variable.
   */
  private static int serialNumber = 0;

  /**
   * This is a dummy variable that is a copy of the "this" reference. If you do
   * this, you can refer to this object instance either through the "this"
   * keyword, or through the "this" keyword.
   */
  private final Thing me = this;

  /**
   * This class variable is a list of Thing objects that we'll use to keep track
   * of all the object instances created.
   */
  private static LinkedList<Thing> thingList = new LinkedList<Thing> ( );

  /**
   * This is an instance variable for the name of this object instance.
   */
  private String name;

  /**
   * The parameter less constructor sets a default name, and assigns a unique
   * serial number to this object instance. Note that this is the *only* place
   * where the serialNumber class variable is changed.
   */
  public Thing ( ) {
    name = "Unknown";
    mySerial = ++serialNumber;

    // Add this thing to our list of things.
    thingList.add ( this );
  }

  /**
   * This is a parameterized constructor for the thing class. In order to get a
   * serial number assigned, we call the this() constructor, which is the
   * parameterless constructor defined above. Note, in this case the implicit
   * call to super() goes away, and is replaced by the explicit "this()" call.
   * The super constructor is instead called from the parameterless constructor.
   * @param name The name to give this object
   */
  public Thing ( String name ) {
    this ( );
    this.name = name;
  }

  /**
   * String representation for this object
   */
  @Override
  public String toString ( ) {
    return "Thing (Name: " + this.name + ") " + this.mySerial;
  }

  public static void main ( String[] args ) {
    // An external list of things
    final Thing[] things = new Thing[5];

    // See that two things have different serial numbers
    System.out.println ( things[0] = new Thing ( ) );
    System.out.println ( things[1] = new Thing ( ) );

    // A 3rd thing
    final Thing t3 = new Thing ( );
    things[2] = t3;

    // Note that I can access t3, and t3.me and they are the same thing, but
    // that it is not possible to say t3.this because the "this" reference is 
    // *only* available from within the code for the particular class, and can 
    // not be referred to from a static context like the main method.
    System.out.println ( t3 );
    System.out.println ( t3.me );

    // Create a named thing
    final Thing t4 = new Thing ( "Steve" );
    things[3] = t4;
    System.out.println ( t4 );

    // Another named thing
    things[4] = new Thing ( "Oscar" );

    // Iterate through all the things to get the one with serial number 2
    for ( final Thing t : things ) {
      if ( t.mySerial == 2 )
	System.out.println ( t );
    }

  }
}
