/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 10, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture10;

/**
 * Concrete implementation of a Pig animal
 */
public class Pig extends FarmAnimal {

  public Pig ( ) {
    super ( "Oink" );
  }
}
