/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 10, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture10;

/**
 * An animal that lives on a farm
 */
public abstract class FarmAnimal extends Animal {

  /**
   * Constructor for FarmAnimal, must be called from subclass of FarmAnimal
   * @param sound
   */
  public FarmAnimal ( String sound ) {
    super ( sound );
  }

  /**
   * @see Animal#eat(Object)
   */
  @Override
  public void eat ( Object x ) {

  }

}
