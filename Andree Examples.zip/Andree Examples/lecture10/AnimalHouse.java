/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 10, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture10;

/**
 * 
 */
public class AnimalHouse {

  /**
   * @param args
   */
  public static void main ( String[] args ) {
    final Animal p = new Pig ( );
    System.out.println ( p.getSound ( ) );
    final Animal w = new Wolf ( );
    w.eat ( new Piglet ( ) );
    w.eat ( new Wolf ( ) );
  }

}
