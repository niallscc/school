/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 10, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture10;

/**
 * The piglet is defined as a subclass of Pig, this may be subject to discussion
 * in class on Friday. Please think about what you think of this
 * classification...
 */
public class Piglet extends Pig {

  @Override
  public String getSound ( ) {
    return "Eeeek";
  }
}
