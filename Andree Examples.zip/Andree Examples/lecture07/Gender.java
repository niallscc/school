/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 3, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture07;

/**
 * Simple enumeration of the sexes.
 */
public enum Gender {
  FEMALE, MALE;
}

