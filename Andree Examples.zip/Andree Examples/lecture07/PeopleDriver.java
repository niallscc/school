/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 3, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture07;

import java.awt.Color;

/**
 * This class is supposed to show
 */
public class PeopleDriver {

  public static void main ( String[] args ) {
    // This is a validly created person
    Person p = new Person ( Gender.FEMALE, Color.GREEN, 45, "Bettie" );

    // However, this so is this, and it may not be so good. We'll have to look
    // into ways in which we can fix that.
    Person p2 = new Person ( null, null, -67, null );

    // Both individuals can be printed out.
    System.out.println ( p );
    System.out.println ( p2 );
  }
}
