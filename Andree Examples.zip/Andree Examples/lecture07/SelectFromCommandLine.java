/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 3, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture07;

import java.util.Scanner;

/**
 * Example that shows in detail how to use a switch statement to choose from
 * multiple choices entered from the command line.
 */
public class SelectFromCommandLine {

  /**
   * Our main method runs the show.
   * @param args Command line arguments, not used in this application.
   */
  public static void main ( String[] args ) {
    Scanner keyboard = new Scanner ( System.in );
    int choice = getMenuChoice ( keyboard );
    switch ( choice ) {
      case 1:
	System.out.println ( "Running draw square" );
	break;
      case 2:
	System.out.println ( "Running epicycle" );
	break;
      case 3:
	System.out.println ( "Run cool!" );
	break;
      case 0:
	System.out.println ( "Bye" );
	System.exit ( 0 );
	break;
      default:
	System.err.println ( "Shouldn't get here" );
	System.exit ( 1 );
    }

  }

  /**
   * Method to read valid menu choices from the keyboard.
   * @param keyboard
   * @return
   */
  private static int getMenuChoice ( Scanner keyboard ) {
    // Give user a prompt
    int userChoice;

    // Wait for appropriate answer
    do {
      System.out.print ( "Please enter a choice between 1 and 3: " );
      userChoice = keyboard.nextInt ( );
    } while ( userChoice < 1 || userChoice > 3 );

    // And return the valid answer.
    return userChoice;
  }

}
