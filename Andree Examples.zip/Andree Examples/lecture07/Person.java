/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 3, 2010)
 * @version 1.1 (Feb 5, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture07;

import java.awt.Color;

/**
 * The person class is supposed to represent what a Person is, and can do. Note,
 * at this point, it is still a work in progress.
 */
public class Person {

  /** Person's gender. */
  public final Gender gender;

  /** Person's eye color. */
  public final Color eyeColor;

  /**
   * Person's age in years. Note that in the new version 2 we changed this so
   * that the student class in the lecture08 package can access it directly.
   */
  protected int ageInYears;

  /** Person's name. */
  private String name;

  /**
   * Create a person
   * @param gender Gender of person
   * @param eyeColor Eye-color of person
   * @param age Age of person measured in years
   */
  public Person ( Gender gender, Color eyeColor, int age, String name ) {
    // Note the use of the "this" keyword to refer to an instance varaiable
    // rather than the local method parameter
    this.gender = gender;
    this.eyeColor = eyeColor;
    this.ageInYears = age;
    this.name = name;
  }

  /**
   * String representation of the person.
   */
  @Override
  public String toString ( ) {
    return "Name: " + name + ", Gender: " + gender + ", EyeColor: " + eyeColor
	+ ", Age: " + ageInYears + " years";
  }
}
