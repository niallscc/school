/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 5, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture30;

/**
 * Example of a simple recursive function.
 */
public class Factorial {

  public static long factorial ( long n ) {
    if ( n <= 1 )
      return 1;
    return n * factorial ( n - 1 );
  }
  
  public static void main ( String[] args ) {
    for ( int i = 0; i < 100; i++ ) {
    long result = factorial ( i );
    System.out.println ( "Factorial ( " + i + " ) = " + result );
    }
  }
  
}

