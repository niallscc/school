/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 2, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture30;

import java.security.InvalidParameterException;

/**
 * A class with a method that santizes database input. I fixed it so it passes
 * the test that we set up in the test class
 */
public class StringOps {

  public static String sanitize ( String input ) {
    String newStr = "";

    if ( input == null )
      return newStr;

    // remove anything that comes after an end parenthesis
    int parenIndex = input.indexOf ( ')' );
    if ( parenIndex > 0 )
      newStr = input.substring ( 0, parenIndex );
    else
      newStr = input;

    // First, remove all back-slashes already in the string
    newStr = newStr.replaceAll ( "\\\\", "" );

    // Then make sure to escape all quotes in the string
    newStr = newStr.replaceAll ( "[\']", "\\\\\'" );
    newStr = newStr.replaceAll ( "[\"]", "\\\\\"" );

    return newStr;
  }

  /**
   * Find the first index of the character ch in the string str starting at
   * index index.
   * @param str
   * @param ch
   * @param index
   * @return
   * @throws IndexOutOfBoundsException
   * @throws InvalidParameterException
   */
  public static int findIndex ( String str, char ch, int index )
      throws IndexOutOfBoundsException, InvalidParameterException {
    if ( str == null ) {
      throw new InvalidParameterException ( "str can't be null" );
    }
    if ( index < 0 || index >= str.length ( ) ) {
      throw new IndexOutOfBoundsException ( "Index " + index
	  + " is out of bounds" );
    }

    return str.indexOf ( ch, index );
  }

}
