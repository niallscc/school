/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 2, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture30;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * A simple JUnit test class. Now featuring a successfully thrown exception.
 */
public class TestStringOps {

  /**
   * Test method for
   * {@link edu.unm.cs.cs251.andree.spring10.lecture29.StringOps#sanitize(java.lang.String)}
   * .
   */
  @Test
  public void testSanitize ( ) {
    String theInput = "Bobby\"); drop table students;";
    String expected = "Bobby\\\"";
    String theInput2 = "Bill O'Really";
    String expected2 = "Bill O\\\'Really";

    String output = StringOps.sanitize ( theInput );
    assertEquals ( expected, output );

    String output2 = StringOps.sanitize ( theInput2 );
    assertEquals ( expected2, output2 );

  }

  @Test
  public void testNullInput ( ) {
    String output = StringOps.sanitize ( null );
    assertEquals ( "", output );
  }

  @Test
  public void testIndexMethod ( ) {
    int index = StringOps.findIndex ( "Hello there", 'e', 3 );
    assertEquals ( 8, index );
  }

  @Test ( expected = IndexOutOfBoundsException.class )
  public void testIndexMethodIndexError ( ) {
    int index = StringOps.findIndex ( "Hello there", 'e', -1 );
  }

}
