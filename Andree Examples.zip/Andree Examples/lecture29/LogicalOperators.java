/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 2, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture29;

/**
 * A few examples that shows how logical opertors are different from bit-wise
 * operators in Java.
 */
public class LogicalOperators {

  public static void main ( String[] args ) {
    int x = 10;
    
    // Try to figure out why the outputs are what they are in the following
    // examples!
    
    System.out.println ( x << 1 );
    System.out.println ( x & 1 );
    System.out.println ( x | 1 );
    System.out.println ( x & 3 );
    System.out.println ( x != 0 && 3 != 0 );

    //   1010
    // & 0001
    // ------
    //   0000
  }

}
