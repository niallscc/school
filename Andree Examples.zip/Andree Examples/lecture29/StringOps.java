/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 2, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture29;

/**
 * A class with a method that santizes database input.
 * I fixed it so it passes the test that we set up in the test class
 */
public class StringOps {

  public static String sanitize ( String input ) {
    String newStr = null;

    // remove anything that comes after an end parenthesis
    int parenIndex = input.indexOf ( ')' );
    if ( parenIndex > 0 )
      newStr = input.substring ( 0, parenIndex );
    else
      newStr = input;
    
    // First, remove all back-slashes already in the string
    newStr = newStr.replaceAll ( "\\\\", "" );
    
    // Then make sure to escape all quotes in the string
    newStr = newStr.replaceAll ( "[\']", "\\\\\'" );
    newStr = newStr.replaceAll ( "[\"]", "\\\\\"" );
    
    return newStr;
  }
  
}
