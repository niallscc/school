/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 7, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture31;

import java.util.List;

/**
 * Defines an interface to a library database backend.
 */
public interface Library {

  /**
   * How a book title is different from a book.
   */
  public interface BookTitle {
    /**
     * Get the title of the book
     * @return title of the book
     */
    public String getTitle ( );

    /**
     * Get the author of the book
     * @return author of the book
     */
    public String getAuthor ( );

    /**
     * Get the unique id of the book.
     * @return unique id of the book
     */
    public BookId getId ( );
  }

  /**
   * Defines what a bookId is, even though it's empty, it forces the
   * implementing classes to implement this interface.
   */
  public interface BookId {

    /**
     * Create a string representation of this ID. (Essentially the same as
     * toString but can't be ignored if it's defined here, while the toString is
     * inherited from the Object class.)
     * @return string representation of this ID.
     */
    public String makeString ( );
  }

  /**
   * Defines what a book is
   */
  public abstract class Book {

    /**
     * Get the title for this book
     * @return title for this book
     */
    public abstract BookTitle getBookTitle ( );

    /**
     * Get the page count for this book
     * @return page count for this book
     */
    public abstract int getPageCount ( );

    /**
     * Gets a string representation of the book page requested.
     * @param page the page number to return
     * @return a string representation of the requested page
     * @throws BookException if the requested page does not exist
     */
    public abstract String getPage ( int page ) throws BookException;

    /**
     * Exception class for books
     */
    public static class BookException extends RuntimeException {
      private static final long serialVersionUID = 5877011237016925562L;

      public BookException ( String msg ) {
	super ( msg );
      }
    }
  }

  /**
   * Get a list of book titles for this library
   * @return list of book titles for this library
   */
  public List<BookTitle> getBookList ( );

  /**
   * Get a specific book object out of this database
   * @param id Id for the book to get
   * @return the book object for the specified id or null if the book is not
   *         found in the database
   */
  public Book getBook ( BookId id );

}
