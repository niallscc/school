/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 7, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture31;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 
 */
public class Database implements Library {

  /**
   * Internal representation of a book
   */
  private class Book extends Library.Book {

    private final BookTitle title;
    private final int pageCount;

    /**
     * Create a book.
     * @param title The title of this book
     * @param author The author of this book
     * @param isbn ISBN number for this book
     * @parage pageCount page count for this book
     */
    private Book ( String title, String author, String isbn, int pageCount ) {
      this.title = new BookTitle ( title, author, new BookId ( isbn ) );
      this.pageCount = pageCount;
    }

    /** @see edu.unm.cs.cs251.andree.spring10.lecture31.Library.Book#getBookTitle() */
    @Override
    public BookTitle getBookTitle ( ) {
      return title;
    }

    /** @see edu.unm.cs.cs251.andree.spring10.lecture31.Library.Book#getPage(int) */
    @Override
    public String getPage ( int page ) throws BookException {
      if ( page < 1 || page > getPageCount ( ) )
	throw new BookException ( "No such page exists" );

      // Lame example but works
      return "Page " + page;
    }

    /** @see edu.unm.cs.cs251.andree.spring10.lecture31.Library.Book#getPageCount() */
    @Override
    public int getPageCount ( ) {
      return pageCount;
    }

    @Override
    public String toString ( ) {
      return title.toString ( );
    }
  }

  private class BookId implements Library.BookId, Comparable<BookId> {

    private final String id;

    private BookId ( String isbn ) {
      id = isbn;
    }

    /* (non-Javadoc)
     * @see edu.unm.cs.cs251.andree.spring10.lecture31.Library.BookId#makeString()
     */
    @Override
    public String makeString ( ) {
      return id;
    }

    @Override
    public String toString ( ) {
      return id;
    }

    /* (non-Javadoc)
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo ( BookId o ) {
      return o.id.compareTo ( id );
    }

  }

  private class BookTitle implements Library.BookTitle, Comparable<BookTitle> {

    private final String title;
    private final String author;
    private final BookId id;

    private BookTitle ( String title, String author, BookId id ) {
      this.title = title;
      this.author = author;
      this.id = id;
    }

    /** @see edu.unm.cs.cs251.andree.spring10.lecture31.Library.BookTitle#getAuthor() */
    @Override
    public String getAuthor ( ) {
      return author;
    }

    /** @see edu.unm.cs.cs251.andree.spring10.lecture31.Library.BookTitle#getId() */
    @Override
    public Library.BookId getId ( ) {
      return id;
    }

    /** @see edu.unm.cs.cs251.andree.spring10.lecture31.Library.BookTitle#getTitle() */
    @Override
    public String getTitle ( ) {
      return title;
    }

    @Override
    public int compareTo ( BookTitle t ) {
      return t.getTitle ( ).compareTo ( getTitle ( ) );
    }

    @Override
    public String toString ( ) {
      return "\"" + getTitle ( ) + "\" by " + getAuthor ( );
    }

  }

  /** My list of books. */
  private final LinkedList<Book> bookList = new LinkedList<Book> ( );

  /**
   * Create an initial database, set up database connection, etc.
   */
  public Database ( ) {
    bookList.add ( new Book ( "I can program", "Andree", "123-456-789", 300 ) );
    bookList.add ( new Book ( "I can debug", "Brian", "345-123-987", 286 ) );
  }

  /**
   * @see edu.unm.cs.cs251.andree.spring10.lecture31.Library#getBook(edu.unm.cs.cs251.andree.spring10.lecture31.Library.BookId)
   */
  @Override
  public Library.Book getBook ( Library.BookId id ) {
    final Library.Book theBook = null;
    for ( Book b : bookList ) {
      if ( b.getBookTitle ( ).getId ( ) == id )
	return b;
    }
    return theBook;
  }

  /* (non-Javadoc)
   * @see edu.unm.cs.cs251.andree.spring10.lecture31.Library#getBookList()
   */
  @Override
  public List<Library.BookTitle> getBookList ( ) {
    final ArrayList<Library.BookTitle> titleList = new ArrayList<Library.BookTitle> ( );
    for ( final Book book : bookList )
      titleList.add ( book.getBookTitle ( ) );
    return titleList;
  }

}
