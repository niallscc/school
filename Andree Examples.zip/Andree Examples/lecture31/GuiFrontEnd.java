/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 7, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture31;

import java.util.List;

import edu.unm.cs.cs251.andree.spring10.lecture31.Library.BookTitle;

/**
 * An example GUI frontend only tied to the backend by an interface.
 */
public class GuiFrontEnd {

  public static void main ( String[] args ) {
    Library lib = new Database ( );
    List<BookTitle> bookList = lib.getBookList ( );
    for ( BookTitle book : bookList ) {
      System.out.println ( "\"" + book.getTitle ( ) + "\" by "
	  + book.getAuthor ( ) );
    }

    System.out.println ( lib.getBook ( bookList.get ( 0 ).getId ( ) ) );
  }

}
