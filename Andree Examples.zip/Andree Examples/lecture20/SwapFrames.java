/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 5, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture20;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * A program that shows how you can swap between two different frames, making
 * sure only one is visible at time.
 */
public class SwapFrames {

  /** References to the two frames. */
  private JFrame f1, f2;

  public SwapFrames ( ) {

    // Create the frames
    f1 = new JFrame ( "Frame1" );
    f1.setSize ( new Dimension ( 400, 400 ) );
    f2 = new JFrame ( "Frame2" );
    f2.setSize ( new Dimension ( 400, 400 ) );

    // Add buttons with functionality
    JButton b1 = new JButton ( "Switch to frame 2" );
    b1.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	f1.setVisible ( false );
	f2.setVisible ( true );
      }
    } );
    f1.add ( b1, BorderLayout.SOUTH );

    // Add second button with functionality
    JButton b2 = new JButton ( "Switch to frame 1" );
    b2.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	f2.setVisible ( false );
	f1.setVisible ( true );
      }
    } );
    f2.add ( b2, BorderLayout.NORTH );

    // Set only frame one to be visible initially
    f1.setVisible ( true );
  }

  /**
   * @param args
   */
  public static void main ( String[] args ) {
    new SwapFrames ( );
  }

}
