/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 5, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture20;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * Show how to set up a tabbed pane using jpanels
 */
public class TestTabbedPane extends SimpleGUI {

  /**
   * A panel used for drawing an image on
   */
  private class ImagePanel extends JPanel {
    private static final long serialVersionUID = 1L;

    @Override
    public void paintComponent ( Graphics g ) {
      if ( theImage != null ) {
	final AffineTransform at = new AffineTransform ( );
	final double scaleX = getWidth ( ) / (double) theImage.getWidth ( );
	final double scaleY = getHeight ( ) / (double) theImage.getHeight ( );
	at.scale ( scaleX, scaleY );
	( (Graphics2D) g ).drawRenderedImage ( theImage, at );
      }
    }
  }

  /** The tabbed pane itself. */
  JTabbedPane jtp;

  /** The three panels used on tab 1, 2, and 3 respectively. */
  JPanel panel1, panel2, panel3;

  /** Reference to the image in tab 4. */
  private BufferedImage theImage;

  private static final long serialVersionUID = 1L;

  /**
   * Create the GUI
   */
  public TestTabbedPane ( ) {
    super ( "Tabbed pane" );

    // Create the tabbed pane
    jtp = new JTabbedPane ( );
    this.add ( jtp, BorderLayout.CENTER );

    // Add panels with contents to it
    panel1 = new JPanel ( );
    final JLabel p1l = new JLabel ( "Panel 1" );
    panel1.add ( p1l );
    panel2 = new JPanel ( );
    final JLabel p2l = new JLabel ( "Panel 2" );
    panel2.add ( p2l );
    panel3 = new JPanel ( );
    final JLabel p3l = new JLabel ( "Panel 3" );
    panel3.add ( p3l );

    // Test to see if we can cause a close button in one pane to
    // remove that tab from the layout - Yes, we can!
    final JButton b = new JButton ( "Close" );
    panel3.add ( b );
    b.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	jtp.remove ( panel3 );
	TestTabbedPane.this.validate ( );
      }
    } );

    jtp.addTab ( "Panel 1", panel1 );
    jtp.addTab ( "Panel 2", panel2 );
    jtp.addTab ( "Panel 3", panel3 );

    // Read the image from the file in a subpackage located directly in 
    // relation to this class.
    final InputStream imgStream = TestTabbedPane.class
	.getResourceAsStream ( "images/Java.jpg" );
    try {
      theImage = ImageIO.read ( imgStream );
    } catch ( final IOException e1 ) {
      System.err.println ( "Unable to load image" );
    }

    jtp.addTab ( "Image Panel", new ImagePanel ( ) );

  }

  /**
   * Main method
   * @param args Command line arguments not use here.
   */
  public static void main ( String[] args ) {
    new TestTabbedPane ( ).setVisible ( true );
  }

}
