/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.1 (Mar 5, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.exam1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JPanel;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * This class is going to be the base for most of the questions asked on the
 * first exam for CS251, Spring 2010, March 12. Therefore, it's important that
 * you review this and understand what is going on before the actual exam takes
 * place.
 * @version 1.1 Mar 5, 2010
 */
public class JFig extends SimpleGUI {

  /**
   * A listener class for mouse events. It's used to detect where and when mouse
   * clicks within the canvas are received.
   * @author Andree Jacobson ( andree@unm.edu )
   */
  public class MyMouseListener extends MouseAdapter {

    /** X and Y coordinates for the mouse when button pressed */
    private int _centerX, _centerY;

    /**
     * When the mouse is pressed, record the mouse position
     * @param e The mouse event causing us to execute this code
     */
    public void mousePressed ( MouseEvent e ) {
      _centerX = e.getX ( );
      _centerY = e.getY ( );
    }

    /**
     * When the mouse button is released, record some data about the movement
     * and store the shape into a list of shapes.
     * @param e The mouse event causing us to execute this code
     */
    public void mouseReleased ( MouseEvent e ) {

      // Calculate some generic distances
      int width = Math.abs ( _centerX - e.getX ( ) );
      int height = Math.abs ( _centerY - e.getY ( ) );

      // Calculate and create shape specific stuff
      switch ( _currShape ) {
	case CIRCLE:
	  int radius = (int) Math.sqrt ( width * width + height * height );
	  Ellipse2D.Double e2d = new Ellipse2D.Double ( _centerX - radius,
	      _centerY - radius, radius << 1, radius << 1 );
	  _shapes.add ( new AShape ( e2d, _currColor ) );
	  break;
	case RECTANGLE:
	  int ulx = Math.min ( _centerX, e.getX ( ) );
	  int uly = Math.min ( _centerY, e.getY ( ) );
	  Rectangle2D.Double r2d = new Rectangle2D.Double ( ulx, uly, width,
	      height );
	  _shapes.add ( new AShape ( r2d, _currColor ) );
	  break;
      }

      // Repaint the canvas since we added another object
      canvas.repaint ( );
    }

    /**
     * This method added to make sure that we can click a shape and 'raise' it
     * to the top of the list.
     */
    public void mouseClicked ( MouseEvent e ) {
      _shapes.removeLast ( );
      for ( int i = _shapes.size ( ) - 1; i >= 0; i-- ) {
	if ( _shapes.get ( i ).shape.contains ( e.getX ( ), e.getY ( ) ) ) {
	  _shapes.addLast ( _shapes.remove ( i ) );
	  break;
	}
      }
      canvas.repaint ( );
    }

  }

  /**
   * Listener for mouse motions.
   */
  public class MyMouseMotionListener extends MouseMotionAdapter {

    /**
     * Keeps track of the location when the mouse button is depressed
     */
    public void mouseDragged ( MouseEvent e ) {
      // Capture current coordinates and update view accordingly
      _currCoord.setLocation ( e.getX ( ), e.getY ( ) );
    }

    /**
     * Keeps track of the mouse location when the mouse button is not pressed
     */
    public void mouseMoved ( MouseEvent e ) {
      // Capture current coordinates and update view accordingly
      updateLocation ( e.getX ( ), e.getY ( ) );
    }

  }

  /**
   * Small inner class that keeps track of a shape and its color.
   * @author Andree Jacobson ( andree@unm.edu )
   */
  private class AShape {

    /** Current shape */
    public Shape shape;

    /** Current color */
    public Color color;

    /**
     * Constructor for this shape holder
     * @param s The shape
     * @param c The color of shape s
     */
    public AShape ( Shape s, Color c ) {
      shape = s;
      color = c;
    }
  }

  /**
   * Create our own drawing canvas as a lightweight component.
   * @author Andree Jacobson ( andree@unm.edu )
   */
  private class DrawCanvas extends JPanel {
    /**
     * To keep the java compiler happy
     */
    private static final long serialVersionUID = 1L;

    /**
     * Default constructor, basically just updates size
     */
    public DrawCanvas ( ) {
      setPreferredSize ( new Dimension ( 400, 400 ) );
    }

    /**
     * Override the default paintComponent, clear the canvas first, draws all
     * the elements stored in the list of shapes
     */
    public void paintComponent ( Graphics g ) {
      Graphics2D g2d = (Graphics2D) g;
      g2d.setBackground ( getBackground ( ) );

      // Always clearing the background like this is a death trap when you 
      // want to create animations, things get really flipped out
      g2d.clearRect ( 0, 0, getWidth ( ), getHeight ( ) );
      Color oldC = g2d.getColor ( );

      // Draw the shapes in the list using the correct color
      for ( AShape s : _shapes ) {
	g2d.setColor ( s.color );
	g2d.fill ( s.shape );
	g2d.setColor ( Color.BLACK );
	g2d.draw ( s.shape );
      }

      // Restore original drawing color
      g2d.setColor ( oldC );

      // Update the mouse location based on the last stored coordinate since
      // this is not a mouse event
      updateLocation ( _currCoord.x, _currCoord.y );

    }
  }

  /**
   * Enumeration of the shapes that we allow in our figures
   */
  private enum Shapes {
    CIRCLE, RECTANGLE,
  }

  /**
   * To keep the Java compiler happy and warning free
   */
  private static final long serialVersionUID = 1L;

  /**
   * Main method to create and show GUI.
   * @param args Command line arguments (currently ignored)
   */
  public static void main ( String[] args ) {
    JFig fdp = new JFig ( );
    fdp.setVisible ( true );
  }

  /** List of the shapes drawn on the canvas */
  private LinkedList<AShape> _shapes = new LinkedList<AShape> ( );

  /**
   * Current position of the mouse pointer, final since we can update the values
   * within the object without changing the reference to the object itself.
   */
  private final Point _currCoord = new Point ( );

  /**
   * Buffer for fast string handling.
   */
  private final StringBuffer _locBuf = new StringBuffer ( );

  /** Current shape mode selected from menu */
  private Shapes _currShape = Shapes.CIRCLE;

  /** Current color selected for painting */
  private Color _currColor = Color.PINK;

  /** Reference to the canvas we're drawing on */
  private DrawCanvas canvas;

  /** Memory for undone shapes */
  private AShape _undone = null;

  /**
   * Default constructor
   */
  public JFig ( ) {
    super ( "Simple JFig Drawing Program" );

    // Set up the canvas and add appropriate listeners
    canvas = new DrawCanvas ( );
    canvas.addMouseListener ( new MyMouseListener ( ) );
    canvas.addMouseMotionListener ( new MyMouseMotionListener ( ) );
    add ( canvas, BorderLayout.CENTER );

    // Set up the control panel at the bottom of the screen
    JPanel controlPanel = new JPanel ( new FlowLayout ( ) );
    JButton clearButton = new JButton ( "Clear" );
    clearButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	_shapes.clear ( );
	repaint ( );
      }
    } );
    controlPanel.add ( clearButton );

    // Remove the last drawn figure on the screen, i.e., undo
    JButton undoButton = new JButton ( "Undo" );
    undoButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	if ( _shapes.size ( ) > 0 )
	  _undone = _shapes.removeLast ( );
	repaint ( );
      }
    } );
    controlPanel.add ( undoButton );

    // Restore the last drawn figure on the screen, i.e., undo
    JButton redoButton = new JButton ( "Redo" );
    redoButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	if ( _undone != null ) {
	  _shapes.addLast ( _undone );
	  _undone = null;
	  repaint ( );
	}
      }
    } );
    controlPanel.add ( redoButton );

    // Create a thing that can compare two shapes
    final Comparator<AShape> _ashapeComp = new Comparator<AShape> ( ) {
      public int compare ( AShape s0, AShape s1 ) {
	int s0dist = (int) ( Math.pow ( s0.shape.getBounds ( ).x, 2 ) + Math
	    .pow ( s0.shape.getBounds ( ).y, 2 ) );
	int s1dist = (int) ( Math.pow ( s1.shape.getBounds ( ).x, 2 ) + Math
	    .pow ( s1.shape.getBounds ( ).y, 2 ) );
	return s1dist - s0dist;
      }
    };

    // Then create the cascade button and let it sort the shapes based on 
    // criteria set above.
    JButton cascadeButton = new JButton ( "Cascade" );
    cascadeButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	// Need to sort the list of shapes based on their x and y coordinate
	Collections.sort ( _shapes, _ashapeComp );
	repaint ( );
      }
    } );
    controlPanel.add ( cascadeButton );

    JButton quitButton = new JButton ( "Quit" );
    quitButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	System.exit ( 0 );
      }
    } );
    controlPanel.add ( quitButton );
    add ( controlPanel, BorderLayout.SOUTH );

    // Set up the menu panel on the left side of the screen
    JPanel shapePanel = new JPanel ( new FlowLayout ( ) );
    shapePanel.setPreferredSize ( new Dimension ( 65, this.getHeight ( ) ) );
    // Load images from the appropriate location
    BufferedImage[] img = new BufferedImage[3];
    try {
      img[0] = ImageIO.read ( JFig.class.getResource ( "img/circle.gif" ) );
      img[1] = ImageIO.read ( JFig.class.getResource ( "img/rect.gif" ) );
      img[2] = ImageIO.read ( JFig.class.getResource ( "img/color.gif" ) );
    } catch ( IOException e1 ) {
      e1.printStackTrace ( );
      System.err.println ( "Unable to load images" );
      System.exit ( 1 );
    }

    // Set up the circle button with the circle image and update shape based
    // on a click to this button
    JButton circleButton = new JButton ( new ImageIcon ( img[0]
	.getScaledInstance ( 35, 35, 0 ) ) );
    circleButton.setPreferredSize ( new Dimension ( 50, 50 ) );
    circleButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	_currShape = Shapes.CIRCLE;
      }
    } );
    shapePanel.add ( circleButton );

    // Set up the rectangle button with the rectangle image and update the 
    // shape based on a click to this button
    JButton rectButton = new JButton ( new ImageIcon ( img[1]
	.getScaledInstance ( 35, 35, 0 ) ) );
    rectButton.setPreferredSize ( new Dimension ( 50, 50 ) );
    rectButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	_currShape = Shapes.RECTANGLE;
      }
    } );
    shapePanel.add ( rectButton );

    // Allow users to change color by clicking on this button (marked with 
    // image) through the JColorChooser window
    final JButton colorButton = new JButton ( new ImageIcon ( img[2]
	.getScaledInstance ( 35, 35, 0 ) ) );
    colorButton.setPreferredSize ( new Dimension ( 50, 50 ) );
    colorButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	_currColor = JColorChooser.showDialog ( colorButton, "Pick a color",
	    _currColor );
      }
    } );

    shapePanel.add ( colorButton );

    add ( shapePanel, BorderLayout.WEST );

    // Finally pack the layout of this window and center on screen 
    pack ( );
    setLocationRelativeTo ( null );
  }

  /**
   * Update the location (coordinate), and draw the new location on the canvas
   * along with some nice borders and such.
   * @param x Last seen x position of the mouse pointer
   * @param y Last seen y position of the mouse pointer
   */
  private void updateLocation ( int x, int y ) {
    // Set the currently captured coordinates
    _currCoord.setLocation ( x, y );

    // Update the graphics display
    Graphics2D g2d = (Graphics2D) canvas.getGraphics ( );
    int height = canvas.getHeight ( );
    int width = canvas.getWidth ( );

    // Draw the new location
    Color oldC = g2d.getColor ( );

    // Clear previous location display
    g2d.setBackground ( getBackground ( ) );
    g2d.clearRect ( 3, height - 25, width - 3, 24 );

    // Draw new location. Constants here refer to offsets from borders 
    // of the canvas. Could be written in a better way (using constants)
    g2d.setColor ( Color.BLACK );
    g2d.drawLine ( 0, height - 25, width - 3, height - 25 );
    _locBuf.setLength ( 0 );
    _locBuf.append ( _currCoord.x );
    g2d.drawString ( "X = ", 5, height - 7 );
    g2d.drawString ( _locBuf.toString ( ), 30, height - 7 );
    g2d.drawString ( "Y = ", 75, height - 7 );
    _locBuf.setLength ( 0 );
    _locBuf.append ( _currCoord.y );
    g2d.drawString ( _locBuf.toString ( ), 100, height - 7 );

    // Draw the actual border
    g2d.drawRect ( 0, 0, width - 2, height - 2 );

    // Draw the shade outside the border
    g2d.setColor ( Color.GRAY );
    g2d.drawLine ( 1, height - 1, width - 1, height - 1 );
    g2d.drawLine ( width - 1, 0, width - 1, height );

    // Set the old color back
    g2d.setColor ( oldC );

  }

}
