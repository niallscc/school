/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 22, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture24;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.Timer;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * Yet another sample showing how to animate things using a timer
 */
public class AnimateWithTimer extends SimpleGUI {

  private class ClockPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    @Override
    public void paintComponent ( Graphics g ) {
      super.paintComponent ( g );
      final int width = getWidth ( );
      final int height = getHeight ( );
      final int diameter = Math.min ( width, height ) - 10;
      g.setColor ( Color.black );
      g.drawOval ( 0, 0, diameter, diameter );
      g.setColor ( Color.blue );
      double angle = 2 * Math.PI / 60 * second;
      g.drawLine ( diameter / 2, diameter / 2, (int) ( diameter / 2 + diameter
	  / 2 * Math.cos ( angle ) ), (int) ( diameter / 2 + diameter / 2
	  * Math.sin ( angle ) ) );
      final double minute = second / 600;
      g.setColor ( Color.red );
      angle = 2 * Math.PI / 60 * minute;
      g.drawLine ( diameter / 2, diameter / 2, (int) ( diameter / 2 + diameter
	  / 2 * Math.cos ( angle ) ), (int) ( diameter / 2 + diameter / 2
	  * Math.sin ( angle ) ) );

    }
  }

  private static final long serialVersionUID = 1L;

  private final Timer timer;
  private double second;
  private final ClockPanel cp;

  public AnimateWithTimer ( ) {
    super ( "Clock animation" );
    cp = new ClockPanel ( );
    this.add ( cp, BorderLayout.CENTER );
    timer = new Timer ( 100, new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	second += .1;
	cp.repaint ( );
	// timer.setDelay ( timer.getDelay ( )-10 );
      }
    } );
    timer.start ( );
  }

  public static void main ( String[] args ) {
    new AnimateWithTimer ( ).setVisible ( true );
  }

}
