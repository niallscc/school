/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Jan 25, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture03;

/**
 * This class was designed to show many examples of loops and expressions. Note
 * that there's no particular purpose to the loop examples below, other than
 * showing the syntax of the loops themselves.
 */
public class LoopExamples {

  /**
   * The main method.
   * @param args
   */
  public static void main ( String[] args ) {
    int x = 10;
    while ( x >= 0 ) {
      System.out.println ( x );
      x--;
    }

    int y = 0;
    // Pitfall - Lazy evaluation
    while ( x < 10 || x / y > 0 ) {
      System.out.println ( "x = " + x );
      x = x + 1;
      
      // Added this so program won't fail. Note that the above
      // divide by 0 doesn't happen unless x becomes 10 or greater.
      if ( x == 10 )
	break;
    }

    // These are infinite loops that you can create
    // while ( true );
    // do { } while ( true );
    // for ( ;; );

    // Don't put that semicolon there!!!!
    // If you do - Not good!
    //    while ( x > 0 );{
    //      System.out.println ( x );
    //      x--;
    //    }

    // Int's are not booleans :)
    //    while ( (boolean) x ) {
    //    }

    // Basic for loop
    for ( int i = 0; i < 10; i++ ) {
      System.out.println ( i );
    }

    // Is the same as this while loop below, except the variable declaration is inside the loops.
    int i = 0;
    while ( i < 10 ) {
      { // For loop body

      }
      i++;
    }

    // The comma operator can be used to put multiple variables in a for loop.
    for ( int p = 0, q = 10; p < q; p++, q-- ) {
      System.out.println ( "p = " + p + ", q = " + q );
    }

    // Post / pre increment
    int q = 10;
    int z = q++ - --q + ++q + ++q - q++ + ++q;
    System.out.println ( "q = " + q + ", z = " + z );

    // The enhanced for loop (often called for-each loop)
    // iterates over all elements in a list or array.
    String[] names = { "Oscar", "Fredrick", "Ellen" };
    for ( String s : names ) {
      System.out.println ( s );

      // Note that changes to the loop variable does not change the content 
      // of the array itself.
      s = s + s;
    }

    // The enhanced for loop replaces the below construct.
    for ( int n = 0; n < names.length; n++ ) {
      String s = names[n];
      System.out.println ( s );
      
      // This however is used to change array content.
      names[n] = names[n] + names[n];
    }

    // And then we see that the changes occurred.
    for ( String s : names ) {
      System.out.println ( s );
    }

  }
}
