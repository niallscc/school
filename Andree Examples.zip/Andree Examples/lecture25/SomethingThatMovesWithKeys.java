/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 24, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture25;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * An example on how to use key listeners to make a thing move on the screen.
 */
public class SomethingThatMovesWithKeys extends SimpleGUI {

  /**
   * @param title
   */
  public SomethingThatMovesWithKeys ( ) {
    super ( "Drawing program" );
    drawPanel = new DrawPanel ( );
    add ( drawPanel, BorderLayout.CENTER );
    this.setFocusable ( false );
    drawPanel.setFocusable ( true );
    drawPanel.requestFocus ( );
  }

  private DrawPanel drawPanel;
  private static final long serialVersionUID = 1L;
  private int crossSize = 5;
  private Point currentPoint = new Point ( crossSize, crossSize );

  private class DrawPanel extends JPanel implements KeyListener {
    private static final long serialVersionUID = 1L;

    public DrawPanel ( ) {
      this.addKeyListener ( this );
      this.addMouseMotionListener ( new MouseAdapter ( ) {
	public void mouseMoved ( MouseEvent e ) {
	  currentPoint = e.getPoint ( );
	  drawPanel.repaint ( );
	}
      } );
    }

    public void paintComponent ( Graphics g ) {
      super.paintComponent ( g );
      if ( currentPoint != null ) {
	g.setColor ( Color.BLUE );
	g.drawLine ( currentPoint.x - crossSize, currentPoint.y - crossSize,
	    currentPoint.x + crossSize, currentPoint.y + crossSize );
	g.drawLine ( currentPoint.x - crossSize, currentPoint.y + crossSize,
	    currentPoint.x + crossSize, currentPoint.y - crossSize );
      }
    }

    @Override
    public void keyPressed ( KeyEvent e ) {
      int keyCode = e.getKeyCode ( );
      switch ( keyCode ) {
	case KeyEvent.VK_RIGHT:
	  if ( currentPoint.x + crossSize < getWidth ( ) )
	    currentPoint.x += 1;
	  break;
	case KeyEvent.VK_LEFT:
	  if ( currentPoint.x - crossSize > 0 )
	    currentPoint.x -= 1;
	  break;
	case KeyEvent.VK_UP:
	  if ( currentPoint.y - crossSize > 0 )
	    currentPoint.y -= 1;
	  break;
	case KeyEvent.VK_DOWN:
	  currentPoint.y += 1;
	  break;
	case KeyEvent.VK_EQUALS:
	  crossSize += 1;
	  break;
      }
      drawPanel.repaint ( );
    }

    @Override
    public void keyReleased ( KeyEvent e ) {

    }

    @Override
    public void keyTyped ( KeyEvent e ) {

    }
  }

  public static void main ( String[] args ) {
    new SomethingThatMovesWithKeys ( ).setVisible ( true );
  }

}
