/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 24, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture25;

import java.awt.Graphics;

import edu.unm.cs.cs251.andree.spring10.prog2.Block;
import edu.unm.cs.cs251.andree.spring10.prog4.interfaces.Drawable;
import edu.unm.cs.cs251.andree.spring10.prog4.shapes.TetrisPiece2D;

/**
 * An example of what the drawable tetris piece class could start looking like.
 */
public class DrawableTetrisPiece implements Drawable {
  private TetrisPiece2D tp2d;
  public DrawableTetrisPiece (TetrisPiece2D thePiece) {
    tp2d = thePiece;
  }

  @Override
  public void draw ( Graphics g, int x, int y ) {
    Block[][] arr = tp2d.getBlockArray ( );
  }
}

