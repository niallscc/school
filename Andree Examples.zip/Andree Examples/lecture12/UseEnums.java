/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 15, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture12;

/**
 * This is an example that shows how to use enum classes. Note this particular
 * example does not use a constructor within the enum, for more examples of such
 * classes, please google "Java Enums" and get the top entry, and you'll be
 * good, and/or read the book chapter on enums.
 */
public class UseEnums {

  /**
   * The weekday enum is there to represent the days of the week.
   */
  public static enum Weekday {

    /** Here are the days. */
    MON, TUE, WED, THU, FRI, SAT, SUN;

    /** The names of the days of the week. */
    private final String dayNames[] = { "Monday", "Tuesday", "Wednesday",
	"Thursday", "Friday", "Saturday", "Sunday" };

    /**
     * Get the enum value for tomorrow.
     * @return enum value for tomorrow
     */
    public Weekday tomorrow ( ) {
      return values ( )[( this.ordinal ( ) + 1 ) % values ( ).length];
    }

    /**
     * The toString method returns the name of the day instead of the enum
     * value.
     */
    @Override
    public String toString ( ) {
      return dayNames[this.ordinal ( )];
    }

    /**
     * Get the enum value for yesterday
     * @return enum value for the day before today
     */
    public Weekday yesterday ( ) {
      return values ( )[( this.ordinal ( ) + 6 ) % values ( ).length];
    }
  }

  /**
   * The main method show how it all fits together.
   * @param args
   */
  public static void main ( String[] args ) {

    // A sample how how it can be used
    final Weekday today = Weekday.MON;
    System.out.println ( today );

    // Iterate over all the days in the enum, and make sure that the 
    // today and tomorrow methods work.
    System.out.println ( "All days:" );
    for ( final Weekday day : Weekday.values ( ) ) {
      System.out.print ( day + " has ordinal " + day.ordinal ( ) );
      System.out.print ( " (Tomorrow is " + day.tomorrow ( ) + ") " );
      System.out.println ( " (Yesterday was " + day.yesterday ( ) + ")" );
    }
  }

}
