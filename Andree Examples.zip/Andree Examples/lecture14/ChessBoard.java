/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 19, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture14;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;

/**
 * Create a chess board of buttons using a GridLayout.
 */
public class ChessBoard extends SimpleGUI {

  private static final long serialVersionUID = 1L;

  public ChessBoard ( ) {
    super ( "Chess" );
    this.setLayout ( new GridLayout ( 8, 8 ) );
    for ( int i = 0; i < 64; i++ ) {
      JButton b = new JButton ( i % 2 == ( i / 8 % 2 ) ? "Black" : "White" );
      b.setPreferredSize ( new Dimension ( 75, 75 ) );
      this.add ( b );
    }
    this.pack ( );
    this.setLocationRelativeTo ( null );
  }

  public static void main ( String[] args ) {
    new ChessBoard ( ).setVisible ( true );
  }

}
