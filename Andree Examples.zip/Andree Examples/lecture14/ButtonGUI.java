/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 19, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture14;

import java.awt.BorderLayout;

import javax.swing.JButton;

/**
 * Shows how to get the buttons in the five areas of the BorderLayout.
 */
public class ButtonGUI extends SimpleGUI {

  private static final long serialVersionUID = 1L;

  public ButtonGUI ( ) {
    super ( "Button GUI" );

    JButton aButton = new JButton ( "Center" );
    this.add ( aButton, BorderLayout.CENTER );

    JButton bButton = new JButton ( "North" );
    this.add ( bButton, BorderLayout.NORTH );

    JButton cButton = new JButton ( "South" );
    this.add ( cButton, BorderLayout.SOUTH );

    JButton dButton = new JButton ( "East" );
    this.add ( dButton, BorderLayout.EAST );

    JButton eButton = new JButton ( "West" );
    this.add ( eButton, BorderLayout.WEST );
  }

  public static void main ( String[] args ) {
    new ButtonGUI ( ).setVisible ( true );
  }

}
