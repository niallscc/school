/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 19, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture14;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * An example of creating a composite layout.
 */
public class CompositeLayoutExample extends SimpleGUI {

  private static final long serialVersionUID = 1L;

  public CompositeLayoutExample ( ) {
    super ( "Composite Layout" );

    JPanel drawPanel = new JPanel ( );
    drawPanel.setBorder ( BorderFactory.createLineBorder ( Color.ORANGE, 10 ) );
    JPanel buttonPanel = new JPanel ( );
    JButton quitButton = new JButton ( "Quit" );
    JButton drawButton = new JButton ( "Draw" );
    buttonPanel.add ( quitButton );
    buttonPanel.add ( drawButton );

    this.add ( buttonPanel, BorderLayout.SOUTH );
    this.add ( drawPanel, BorderLayout.CENTER );
  }

  public static void main ( String[] args ) {
    new CompositeLayoutExample ( ).setVisible ( true );
  }

}
