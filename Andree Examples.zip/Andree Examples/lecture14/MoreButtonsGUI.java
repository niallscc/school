/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 19, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture14;

import java.awt.FlowLayout;

import javax.swing.JButton;

/**
 * Shows how to make a lot of buttons and how the FlowLayout works.
 */
public class MoreButtonsGUI extends SimpleGUI {

  private static final long serialVersionUID = 1L;

  public MoreButtonsGUI ( ) {
    super ( "Lots of buttons!" );
    this.setLayout ( new FlowLayout ( ) );
    for ( int i = 0; i < 100; i++ ) {
      this.add ( new JButton ( "" + i ) );
    }
  }

  public static void main ( String[] args ) {
    new MoreButtonsGUI ( ).setVisible ( true );
  }

}
