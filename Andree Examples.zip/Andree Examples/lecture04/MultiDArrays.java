/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Jan 27, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture04;

/**
 * Example program that shows how to create, access, and modify multidimensional
 * arrays. Some important things to remember here are how the length of
 * sub-dimensions are found by using a partial number of array brackets.
 */
public class MultiDArrays {

  public static void main ( String[] args ) {

    // Creates a 4D array
    String[][][][] values = new String[26][26][26][26];

    // Populate the elements of the 4D array with it's string permutation
    // of four letters A-Z starting with AAAA and ending in ZZZZ.
    for ( int d1 = 0; d1 < values.length; d1++ ) {
      for ( int d2 = 0; d2 < values[d1].length; d2++ ) {
	for ( int d3 = 0; d3 < values[d1][d2].length; d3++ ) {
	  for ( int d4 = 0; d4 < values[d1][d2][d3].length; d4++ ) {
	    
	    // Create the string content by using ascii characters
	    String data = "" + (char) ( 'A' + d1 );
	    data += (char) ( 'A' + d2 );
	    data += (char) ( 'A' + d3 );
	    data = data + (char) ( 'A' + d4 );
	    values[d1][d2][d3][d4] = data;
	  }
	}
      }
    }

    // Access all the elements using enhanced for-loop
    for ( String[][][] dim1 : values ) {
      for ( String[][] dim2 : dim1 ) {
	for ( String[] dim3 : dim2 ) {
	  for ( String dim4 : dim3 ) {
	    System.out.println ( dim4 );
	  }
	}
      }
    }

    // If I try to print out the array, I'll get the very cryptic value
    // [[[[Ljava.lang.String;@19c247a0 which tells me that this is a 4D
    // array of strings, but that's pretty much it.
    System.out.println ( values );

  }

}
