/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Jan 27, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture04;

/**
 * Very short sample program that shows how to access command line arguments
 * from within a Java program.
 */
public class CmdLineArgs {
  
  public static void main ( String[] args ) {
    for ( String s : args ) {
      System.out.println ( s );
    }
  }
  
}
