/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 16, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture35;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.LinkedList;

/**
 * Example that shows how to serialize an object or two to a file on disk, and
 * then how to reload it.
 */
public class TestingSerialization {

  public static class WeirdClass implements Serializable {
    private static final long serialVersionUID = 1L;
    public int x;
    public int y;
    public/* transient */String name;

    public WeirdClass ( String name, int x, int y ) {
      this.x = x;
      this.y = y;
      this.name = name;
    }

    public String toString ( ) {
      return "Name: " + name + " (" + x + "," + y + ")";

    }
  }

  public static void main ( String[] args ) throws IOException {
    FileOutputStream fos = new FileOutputStream ( "/tmp/dataoutput.dat" );
    ObjectOutputStream oos = new ObjectOutputStream ( fos );
    LinkedList<String> myList = new LinkedList<String> ( );
    myList.add ( "Hello world" );
    myList.add ( "This is the second element" );
    myList.add ( "Is this going to work?" );
    oos.writeObject ( myList );
    oos.writeObject ( "This is a real string" );
    oos.writeObject ( new WeirdClass ( "Cool", 10, 50 ) );
    fos.close ( );

    FileInputStream fis = new FileInputStream ( "/tmp/dataoutput.dat" );
    ObjectInputStream ois = new ObjectInputStream ( fis );
    try {
      Object o = ois.readObject ( );
      System.out.println ( o );
      if ( o instanceof LinkedList<?> ) {
	System.out.println ( "I found a linked list" );
      }
      o = ois.readObject ( );
      System.out.println ( o );
      o = ois.readObject ( );
      System.out.println ( o );
    } catch ( ClassNotFoundException e ) {
      e.printStackTrace ( );
    } finally {
      fis.close ( );
    }

  }

}
