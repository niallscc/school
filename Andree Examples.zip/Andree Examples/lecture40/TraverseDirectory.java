/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 28, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture40;

import java.io.File;
import java.io.FileFilter;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JFileChooser;

/**
 * Shows how to traverse a directory structure and extract a list of all .java
 * files in this directory.
 */
public class TraverseDirectory {

  /**
   * The recursive function that actually does the traversing.
   * @param root The root directory in which to start the traversal
   * @param list The list in which we will put the files that we find
   */
  public static void traverseDirectory ( File root, List<File> list ) {
    if ( root != null && root.exists ( ) && root.isDirectory ( ) ) {

      // Get all the entries in this directory that is either a .java file
      // or another directory
      File[] entries = root.listFiles ( new FileFilter ( ) {
	@Override
	public boolean accept ( File pathname ) {
	  return pathname.isDirectory ( )
	      || pathname.getName ( ).endsWith ( ".java" );
	}
      } );

      // Go through the list of all files, and add all the .java files to
      // the list
      for ( File f : entries ) {
	if ( f.isFile ( ) )
	  list.add ( f );
	else
	  // Here's the recursive call
	  traverseDirectory ( f, list );
      }
    }
  }

  /**
   * Main... You know what that one does.
   * @param args Command line arguments.
   */
  public static void main ( String[] args ) {
    
    // Create a file chooser window in which we can only select directories
    JFileChooser jfc = new JFileChooser ( );
    jfc.setFileSelectionMode ( JFileChooser.DIRECTORIES_ONLY );
    
    // Open the file chooser dialog window
    jfc.showOpenDialog ( null );
    
    // Get the directory that the user selected
    File root = jfc.getSelectedFile ( );
    System.out.println ( "You selected " + root );

    // Then populate the list
    LinkedList<File> fileList = new LinkedList<File> ( );
    traverseDirectory ( root, fileList );

    // Print out all the .java files that we found
    for ( File f : fileList )
      System.out.println ( f );
    
    System.out.println ( "List contains: " + fileList.size ( ) + " entries" );

  }

}
