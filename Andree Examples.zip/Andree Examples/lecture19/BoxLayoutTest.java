/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 3, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture19;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * 
 */
public class BoxLayoutTest extends SimpleGUI {

  private static final long serialVersionUID = 1L;

  /**
   * @param title
   */
  public BoxLayoutTest ( String title ) {
    super ( title );
    JPanel p = new JPanel ( );
    p.setLayout ( new BoxLayout ( p, BoxLayout.Y_AXIS ) );
    JButton b = new JButton ( "B" );
    b.setPreferredSize ( new Dimension ( 100, 300 ) );
    p.add ( b );
    JButton c = new JButton ( "C" );
    p.add ( c );
    p.add(new JTextField(10));
    this.add ( p, BorderLayout.CENTER );
  }

  /**
   * @param args
   */
  public static void main ( String[] args ) {
    new BoxLayoutTest ( "Testing Boxlayout" ).setVisible ( true );
  }

}
