/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 3, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture19;

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * 
 */
public class TellKey extends SimpleGUI {

  private static final long serialVersionUID = 1L;

  private class KeyPanel extends JPanel implements KeyListener {
    private static final long serialVersionUID = 1L;

    public KeyPanel ( ) {
      this.addKeyListener ( this );
    }

    @Override
    public void keyPressed ( KeyEvent e ) {
      System.out.println ( "Pressed keycode: " + e.getKeyCode ( ) + " Modifiers: "
	      + KeyEvent.getKeyModifiersText ( e.getModifiers ( ) ) );
      switch ( e.getKeyCode ( ) ) {
	case KeyEvent.VK_DOWN:
	case KeyEvent.VK_SPACE:
	  System.out.println ( "Drop block" );
      }
    }

    @Override
    public void keyReleased ( KeyEvent e ) {
      System.out.println ( "Released keycode: " + e.getKeyCode ( ) );
    }

    @Override
    public void keyTyped ( KeyEvent e ) {

    }
  }

  private KeyPanel kp;

  public TellKey ( ) {
    super ( "Show keys" );
    kp = new KeyPanel ( );
    kp.setFocusable ( true );
    kp.grabFocus ( );
    add ( kp, BorderLayout.CENTER );
  }

  /**
   * @param args
   */
  public static void main ( String[] args ) {
    new TellKey ( ).setVisible ( true );
  }

}
