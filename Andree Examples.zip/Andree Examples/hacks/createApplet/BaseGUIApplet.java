/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Jan 13, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.hacks.createApplet;

import javax.swing.JApplet;

public class BaseGUIApplet extends JApplet {

  private static final long serialVersionUID = 1L;

  //Called when this applet is loaded into the browser.
  public void init ( ) {
    BaseGUI bg = new BaseGUI ( "My Applet" );
    bg.mainWindow.setVisible ( true );
  }
}
