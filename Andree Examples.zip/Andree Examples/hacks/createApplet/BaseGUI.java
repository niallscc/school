/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Sep 30, 2009)
 */
package edu.unm.cs.cs251.andree.spring10.hacks.createApplet;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Very small standard base for a GUI application.
 */
public class BaseGUI {

  /** This is a reference to the main window. */
  protected JFrame mainWindow;

  /**
   * Parameterless constructor with no window title. Note that this constructor
   * actually calls the parameterized constructor
   */
  public BaseGUI ( ) {
    this ( "" );
  }

  private class DrawPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    public void paintComponent ( Graphics g ) {
      // Draw a frame around the panel
      g.setColor ( Color.BLUE );
      g.drawRect ( 0, 0, getWidth ( ) - 1, getHeight ( ) - 1 );
    }
  }

  /**
   * This is the main constructor, it creates a default window and centers it.
   * @param title Title of this GUI window
   */
  public BaseGUI ( String title ) {
    // Create the window
    mainWindow = new JFrame ( );

    // If the title isn't null or empty, then set the title accordingly
    if ( title != null && !title.equals ( "" ) )
      mainWindow.setTitle ( title );

    // Make sure application closes if the window closes
    mainWindow.setDefaultCloseOperation ( JFrame.DISPOSE_ON_CLOSE );

    mainWindow.add ( new DrawPanel ( ), BorderLayout.CENTER );

    // Set a default size of the window
    mainWindow.setSize ( 640, 480 );

    // Center the window on the screen
    mainWindow.setLocationRelativeTo ( null );
  }

  public static void main ( String[] argv ) {
    BaseGUI bg = new BaseGUI ( "My GUI" );
    bg.mainWindow.setVisible ( true );
  }

}
