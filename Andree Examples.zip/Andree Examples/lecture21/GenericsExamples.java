/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Mar 8, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture21;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JPanel;

/**
 * 
 */
public class GenericsExamples {

  private static class Dummy implements Comparable<Dummy> {
    String x;

    public Dummy ( String s ) {
      x = s;
    }

    public String toString ( ) {
      return x;
    }

    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo ( Dummy o ) {
      return -o.x.compareTo ( this.x );
    }
  }

  public static void main ( String[] args ) {
    Object[] objects = new Object[5];
    objects[0] = new Scanner ( System.in );
    objects[1] = new Integer ( 10 );
    objects[2] = new JPanel ( );
    objects[3] = new ArrayIndexOutOfBoundsException ( );
    objects[4] = new Double ( Math.PI );
    for ( Object o : objects ) {
      System.out.println ( o );
    }

    LinkedList<Object> ll = new LinkedList<Object> ( );
    for ( Object o : objects ) {
      ll.add ( o );
    }

    LinkedList<Integer> lli = new LinkedList<Integer> ( );
    for ( Object o : objects ) {
      if ( o instanceof Integer )
	lli.add ( (Integer) o );
    }
    for ( Integer i : lli ) {
      System.out.println ( "Integer: " + i );
    }
    Random randGen = new Random ( );
    for ( int i = 0; i < 10; i++ ) {
      lli.add ( new Integer ( randGen.nextInt ( ) ) );
    }

    Collections.sort ( lli );
    for ( Integer i : lli )
      System.out.println ( i );

    ArrayList<Dummy> dummyList = new ArrayList<Dummy> ( );
    for ( int i = 0; i < 20; i++ ) {
      String content = "";
      for ( int j = 0; j < i; j++ ) {
	content = content + "dummy";
      }
      dummyList.add ( new Dummy ( content ) );
    }

    Collections.shuffle ( dummyList );

    Collections.sort ( dummyList );
    for ( Dummy d : dummyList )
      System.out.println ( d );

  }

}
