/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.prog2;

/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 13, 2007)
 * @version 1.1 (Feb 12, 2010)
 */

public interface Object2D extends Rotate2D {

  /**
   * Representation of a two dimensional dimension. This class is fully
   * implemented and needs no further modifications for this assignment.
   * @author Andree Jacobson (andree@unm.edu)
   * @version 1.0, Feb 12, 2006
   * 
   */
  public static class Dimension2D {

    /**
     * Internal width and height
     */
    protected int _height, _width;

    /**
     * Create a new Dimension2D object with a width, height.
     * @param height Number of rows in the object (greater than 0)
     * @param width Number of columns in the object (greater than 0)
     */
    public Dimension2D ( int height, int width ) {
      _height = height;
      _width = width;
    }

    /**
     * Get height of this dimension object.
     * @return height of object
     */
    public int getHeight ( ) {
      return _height;
    }

    /**
     * Get width in this dimension object.
     * @return width of object
     */
    public int getWidth ( ) {
      return _width;
    }

    /**
     * Get the string representation of this object as a pair of numbers
     * surrounded by brackets as follows:
     * 
     * <pre>
     *   [ height, width ]
     * </pre>
     */
    public String toString ( ) {
      return "[" + _height + "," + _width + "]";
    }

  }

  /**
   * String representation of this two dimensional object
   * @return String representation
   */
  public String toString ( );

  /**
   * Get the dimensions of the current object measured in blocks
   * @return The dimensions of current object measured in blocks
   */
  public Dimension2D getDimension ( );

}
