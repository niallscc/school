/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.prog2;

import edu.unm.cs.cs251.andree.spring10.prog2.Object2D;
import edu.unm.cs.cs251.andree.spring10.prog2.Rotate2D;

/**
 * A simple testing class for the tetris pieces.
 * 
 * Please note, you should copy this driver file from this package into the
 * package in which you have declared your Shape classes. Then, you can 
 * uncomment the seven commented lines below, and run it in order to produce
 * the sample output you can find in the SampleOutput.txt file in this package.
 */
public class Driver {

  public static void main ( String[] args ) {
    Object2D[] pieces = new Object2D[7];
    
//    pieces[0] = new IShape ( );
//    pieces[1] = new JShape ( );
//    pieces[2] = new LShape ( );
//    pieces[3] = new OShape ( );
//    pieces[4] = new SShape ( );
//    pieces[5] = new TShape ( );
//    pieces[6] = new ZShape ( );

    for ( Object2D o : pieces ) {
      do {
	System.out.printf ( "%s @ %3d degrees\n", o.getClass ( )
	    .getSimpleName ( ), o.getOrientation ( ) );
	System.out.println ( o );
	o.rotate ( Rotate2D.Direction2D.CW );
      } while ( o.getOrientation ( ) != 0 );
    }
  }

}
