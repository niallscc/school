/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.prog2;

/**
 * A Block is a part of a Tetris piece.
 */
public class Block {

  /**
   * Representing two different types of blocks, either present, or missing.
   */
  public static enum Type {
    MISSING ( " " ), PRESENT ( "*" );

    /**
     * String for this type
     */
    private final String myStr;

    /**
     * Constructor for the Type
     * @param s String for this type
     */
    private Type ( String s ) {
      myStr = s;
    }

    /**
     * @see Object#toString()
     */
    public String toString ( ) {
      return myStr;
    }
  }

  /**
   * The type of this block
   */
  private final Type type;

  /**
   * Create a block of a certain color
   * @param t The type of this block
   */
  public Block ( Type t ) {
    this.type = t;
  }

  /**
   * The type of this object
   * @return the type
   */
  public Type getType ( ) {
    return type;
  }

  /**
   * @see Object#toString()
   */
  @Override
  public String toString ( ) {
    return type.toString ( );
  }
}
