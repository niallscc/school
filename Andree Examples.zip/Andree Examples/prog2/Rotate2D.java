/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.prog2;

/**
 * Defines functionality to rotate in two dimensions.
 */
public interface Rotate2D {

  /**
   * Two dimensional direction
   */
  public static enum Direction2D {

    /**
     * Clock wise rotation.
     */
    CW,

    /**
     * Counter clock wise rotation.
     */
    CCW;

    /**
     * Return the opposing rotation direction.
     * @return Opposing rotation direction.
     */
    public Direction2D opposite ( ) {
      return values ( )[( ordinal ( ) + 1 ) % 2];
    }
  }

  /**
   * Rotate this object 90 degrees in the specified direction.
   * @param dir Direction in which to rotate
   */
  public void rotate ( Direction2D dir );

  /**
   * Gets the orientation (in degrees) of this object in relationship to it's
   * original orientation. I.e., all objects always start out at 0 degree
   * orientation, after you rotate it 90 degrees clock wise, the orientation
   * should be 90. If you however, rotate the object 90 degrees counter clock
   * wise, orientation should be 270.
   * @return The objects current orientation in relationship to it's original
   *         orientation.
   */
  public int getOrientation ( );

}
