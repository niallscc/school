package edu.unm.cs.cs251.andree.spring10.lecture39.hexuko;

/**
 * This class is designed for creating one solution for a suduko board given a 
 * particular size for the board. In the default example, we're creating a 16x16
 * matrix with the possible combinations of the hexadecimal numbers 0-F.
 * @author Andree Jacobson (andree@cs.unm.edu)
 * @version 1.1, 03/13/2006
 */
public class Hexuko {
  
  public static final int defaultSize = 9;
  
  /**
   * Used to set the number of tiles along the side of the board, this variable
   * is only set within one of the public constructors.
   */
  protected int boardSize = 0;
  
  /** 
   * Private internal class to keep track of the possible combinations in each
   * cell. This class helps making decisions about the 
   */
  private class Cell {
    
    /** 
     * Array to hold a flag for each number tried in the board.
     * The last element in the array is used to indicate that the
     * cell has been used or not
     */
    private boolean[] number;
    
    /** The current value assigned to the cell */
    private int value;
    
    /** Default constructor */
    public Cell () {
      this ( defaultSize );
    }
    
    /** 
     * Preferred constructor.
     * @param size Side of the game board ( use 9 for regular sudoku )
     */
    public Cell ( int size ) {
      boardSize = size;
      number = new boolean[size+1];
      value = -1;
      revalidateAll();
    }

    /** 
     * Mutator method for the cell's value
     * @param v Value to set in the cell
     */
    public void setValue ( int v ) { 
      value = v; 
    }
    
    /**
     * Mutator method that clear's the cell's value.
     */
    public void clearValue ( ) { 
      value = -1; 
    }
    
    /**
     * Accessor method for private value field.
     * @return The current value of the cell
     */
    public int getValue ( ) { 
      return value; 
    }
    
    /**
     * Accessor method that checks to see if the current cell has been used in 
     * a partial solution.
     * @return <code>true</code> if cell was used, <code>false</code> otherwise
     */    
    public boolean isUsed() { 
      return number[boardSize]; 
    }
    
    /**
     * Mutator method used to set the cell marked as used. 
     */
    public void setUsed() { 
      number[boardSize] = true; 
    }
    
    /**
     * Mutator method used to set the cell marked as unused.
     */
    public void setUnUsed() { 
      number[boardSize] = false; 
    }

    /**
     * Method to see if all possible values have been tried in this cell
     * @return <code>true</code> if all values of this cell has already been 
     * tried, <code>false</code> if there are still unused possibilities to 
     * try.
     */
    public boolean allTried ( ) {
      for ( int i = 0; i < boardSize; i++ )
	if ( !isTriedValue(i) )
	  return false;
      return true;
    }
    
    /**
     * Mutator method to indicate that an value was tried and has been 
     * invalidated.
     * @param index The ordinal number of the value to invalidate
     */
    public void invalidateValue ( int index ) { 
      number[index] = false; 
    }
    
    /**
     * Mutator method to indicate that an value was tried and has been 
     * validated.
     * @param index The 0-based ordinal number of the value to validate
     */
    public void validateValue ( int index ) { 
      number[index] = true; 
    }
    
    /**
     * Accessor method to check if a value has been tried (i.e. validated).
     * @param index The 0-based ordinal number of value to check
     * @return <code>true</code> if value has been accepted, <code>false</code>
     * if value has been invalidated.
     */
    private boolean isTriedValue ( int index ) { 
      return !number[index]; 
    }
    
    /**
     * Mutator method that change all values to be valid new choices.
     */
    public void revalidateAll ( ) { 
      java.util.Arrays.fill ( number, true );
      number[boardSize] = false; // Indicate cell contains no value
    } 

    /**
     * Use this method to pick a random unused value. Note that the while loop
     * is not optimal for performance, and this implementation might be better
     * to do with a set or something similar.
     * @param rand An externally defined random number generator
     * @return The 0-based ordinal value of a value that haven't been picked yet.
     */
    public int pickUnusedValue ( java.util.Random rand ) {
      int num = rand.nextInt(boardSize);
      while ( isTriedValue(num) ) {
	num = rand.nextInt(boardSize);
      }
      return num;
    }
  }
    
  // Main Hexuko board
  protected Cell[] board;
  
  /**
   * Default constructor
   */
  public Hexuko ( ) {
    this ( 9 );
  }
  
  /**
   * Constructor used to create the board.
   * @param size The side of the board
   */
  public Hexuko ( int size ) {
    boardSize = size;
    board = new Cell[boardSize*boardSize];
    for ( int i = 0; i < boardSize*boardSize; i++ )
      board[i] = new Cell ( boardSize );
  }
  
  /**
   * Check to see if this index is a valid placement for this value 
   * @param val Value to check if valid
   * @param index Index at which the value is to be tried
   * @return <code>true</code> if the value is valid, 
   * <code>false</code> if index is not valid placement for value
   */
  public boolean isValidPlacement ( int val, int index ) {
    
    int row = index / boardSize;
    int col = index % boardSize;
    int i;
    
    // First check current row
    for ( int c = 0; c < boardSize; c++ ) {
      i = row * boardSize + c;
      if ( board[i].isUsed() && board[i].getValue() == val )
	return false;
    }

    // Then check column
    for ( int r = 0; r < boardSize; r++ ) {
      i = r * boardSize + col;
      if ( board[i].isUsed() && board[i].getValue() == val )
	return false;
    }

    // Then check same sub box
    int divider = boardSize/((int)Math.sqrt(boardSize));
    int rowDiv = row/divider, colDiv = col/divider;
    for ( int r = (rowDiv)*divider ; r < (rowDiv)*divider + divider; r++ ) {
      for ( int c = (colDiv)*divider; c < (colDiv)*divider + divider; c++ ) {
	i = r * boardSize + c;
	if ( board[i].isUsed() && board[i].getValue() == val )
	  return false;
      }
    }
    
    return true;
  }

  /**
   * Place a the value i at the index
   * @param index Where to place the value
   * @param i Value to try 
   */
  public void place ( int index, int i ) {
    board[index].setValue(i);
    board[index].setUsed();
    board[index].validateValue(i);
  }

  /**
   * If the value has been tried and was invalid, it needs to be removed.
   * @param index Index of the value to be removed
   * @param i Value to be removed from index
   */
  public void remove ( int index, int i ) {    
    board[index].clearValue();
    board[index].invalidateValue(i);
    board[index].setUnUsed();
  }
  
  /**
   * Recursive backtracking method to create a random solution for a game.
   * 
   * @param index Index at which to start looking for the solution
   * @param rand Externally defined random number generator
   * @return <code>true</code> if solution was found, 
   * <code>false</code> if solution was not found
   */
  public boolean solve ( int index, java.util.Random rand ) {
    
    // Solution by default
    if ( index >= boardSize * boardSize ) 
      return true;
    
    // Pick a number and place on the board
    int i;
    
    // Pick a new value to try, one that was not used
    while ( !board[index].allTried() ) {
      i = board[index].pickUnusedValue ( rand ); 
      if ( isValidPlacement(i, index) ) {
	
	place(index, i);
        //printBoard();
	
	if ( solve ( index + 1, rand ) )
	  return true;
	
	remove(index, i);
        //printBoard();
      
      } else {
	board[index].invalidateValue(i);
      }
    }
    board[index].revalidateAll();	
    return false;
  }
  
  /**
   * For a board with greater than 9 digits resort to letters, of course will 
   * not go farther than z
   * @param val Value to get character value for
   * @return The suitable character for value val
   */
  public char useChar ( int val ) {
    if ( val < 10 && val >= 0 )
      return (char)('0'+val);
    if ( val == -1 ) 
      return '_';
    return (char)(val+'A'-10);
  }
  
  /**
   * Create a string representation of the board.
   * @return String with representation
   */
  public String toString () {
    StringBuilder sb = new StringBuilder();
    for ( int row = 0; row < boardSize; row++ ) {
      for ( int col = 0; col < boardSize; col++ ) {
	int val = board[row*boardSize+col].getValue();
	sb.append(useChar(val));
        sb.append(' ');
      }
      sb.append('\n');
    }
    return sb.toString();
  }
  
  /**
   * Non-static start menu to get around potential problems with static / 
   * non-static compilation problems for intro users. 
   */
  public void start ( ) {
    java.util.Random rand = new java.util.Random();
    solve(0, rand);
    System.out.println(toString());
  }

  /**
   * Main method.
   * @param argv Command line arguments.
   */
  public static void main ( String[] argv ) {
    if ( argv.length == 0 )
      new Hexuko().start();
    else
      new Hexuko(Integer.parseInt(argv[0])).start();
  }
  
}

