package edu.unm.cs.cs251.andree.spring10.lecture39.hexuko;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Graphical interface adapted for Hexuko, by Andree Jacobson
 * 11/8/2005
 * 
 * Original version written for 8 queens by Stuart Reges
 * 2/6/04
 */ 
public class GraphHexuko extends Hexuko {
  
  private JButton[][] myButtons;
  private int myDelay;
  
  /**
   * Constructor that creates the graphical user interface for the Hexuko program.
   * @param size Is the square 
   */
  public GraphHexuko(int size) {
    super(size);
    JFrame f = new JFrame();
    f.setSize(40 * size + 50, 40 * size + 80);
    f.setTitle("Hexuko animation");
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Container contentPane = f.getContentPane();
    
    // initialize delay and add slider to control it at bottom
    final int maxPause = 1000; // milliseconds
    final JSlider slider = new JSlider(0, maxPause - 20);
    myDelay = slider.getValue();
    slider.addChangeListener(new ChangeListener() {
	public void stateChanged(ChangeEvent e)
	{
	myDelay = maxPause - slider.getValue();
	}
	});
    JPanel p = new JPanel();
    p.add(new JLabel("slow"));
    p.add(slider);
    p.add(new JLabel("fast"));
    contentPane.add(p, "South");
    
    // add buttons in the middle for the chess squares
    p = new JPanel(new GridLayout(size, size, 1, 1));
    contentPane.add(p, "Center");
    p.setBackground(Color.black);
    myButtons = new JButton[size][size];
    for (int i = 0; i < size; i++)
      for (int j = 0; j < size; j++)
	p.add(myButtons[i][j] = new JButton());
    
    // bring it on...
    f.setVisible(true);
    f.toFront();
  }
  
  /**
   * Graphically try to place a value at a particular index
   * @param index Index where to try the value
   * @param val Value to try at the index
   */
  public void place(int index, int val) {
    String text = "";
    super.place(index, val);
    text += useChar(val);
    myButtons[index/boardSize][index%boardSize].setText(text);
    pause();
  }
  
  /**
   * Graphically check if a value is a valid placement
   * @param val Value to check
   * @param index Index at which to check value
   */
  public boolean isValidPlacement(int val, int index)
  {
    myButtons[index/boardSize][index%boardSize].setText(useChar(val)+"?");
    pause();
    myButtons[index/boardSize][index%boardSize].setText("");
    return super.isValidPlacement(val, index);
  }
  
  /**
   * Graphically remove a value from a cell
   */
  public void remove(int index, int val)
  {
    super.remove(index, val);
    //myButtons[index/16][index%16].setText("X");
    pause();
    myButtons[index/boardSize][index%boardSize].setText("");
  }
  
  /**
   * Pause method to pause the thread based on the user's wish for speed
   */
  private void pause()
  {
    try {
      Thread.sleep(myDelay);
    } catch (Exception e) {
      throw new InternalError();
    }
  }
  
  /**
   * Start method to avoid the static/non-static problem.
   */
  public void start ( ) {
    java.util.Random rand = new java.util.Random();
    solve(0, rand);
    System.out.println(toString());
  }
  
  /**
   * Main method reading the command line.
   */
  public static void main ( String[] argv ) {
    if ( argv.length == 0 )
      // Default board size is 9
      new GraphHexuko(16).start();
    else
      new GraphHexuko(Integer.parseInt(argv[0])).start();
  }
  
}

