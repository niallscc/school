/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Jan 29, 2010)
 * @version 1.1 (Feb 1, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture06;

/**
 * This class is supposed to help show how to create objects.
 */
public class CreatingObjects {

  public static void main ( String[] args ) {
    Object o = new Object ( ); // Yay... I created an object...
    System.out.println ( o.toString ( ) ); // This prints out ugly hashcode.
    Object o2 = new Object ( ); // Another object!
    System.out.println ( o2 ); // Another ugly hash code

    // Create a SimpleObject instance
    SimpleObject so = new SimpleObject ( );
    System.out.println ( so.toString ( ) );

    // Create a ComplexObject instance
    ComplexObject co = new ComplexObject ( );
    System.out.println ( co );

    // Create a VeryComplicatedObject instance
    VeryComplicatedObject vco = new VeryComplicatedObject ( );
    System.out.println ( vco );
  }

}
