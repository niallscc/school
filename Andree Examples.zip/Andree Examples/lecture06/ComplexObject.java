/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 1, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture06;

/**
 * Shows how to extend (inherit from) a class that we have written ourselves.
 */
public class ComplexObject extends SimpleObject {

  /**
   * The parameterless constructor for this object.
   */
  public ComplexObject ( ) {
    // Note, even when not specified, there's always an implicit call to the
    // super constructor, like so: super(); added as the first line of the 
    // constructor
    System.out.println ( "In ComplexObject constructor" );
  }

  /**
   * This variable "shadows" the declaration of the temperature variable that is
   * declared in the SimpleObject class.
   */
  public double temperature = 20;

  /**
   * This method declaration overrides the
   */
  @Override
  // Annotation used by some compilers, not necessary
  public String toString ( ) {
    // Change the value of the temperature variable declared in this class
    // Note that if the above declaration is not made, it would change the
    // inherited temperature value
    temperature = temperature - 1;

    // The returned string is what the new string representation of this 
    // object will look like.
    return "ComplexObject(" + temperature + "): " + super.toString ( );
  }
}
