/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 1, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture06;

/**
 * A simple object that overrides the definition of the toString method
 * inherited from the Object class.
 */
public class SimpleObject { // extends Object {

  /**
   * Parameterless constructor. Shows an explicit call to the superconstructor
   * of the Object class.
   */
  public SimpleObject ( ) {
    super ( );
    System.out.println ( "In SimpleObject constructor" );
  }

  /**
   * Keep track of the temperature of this object. This is an instance variable,
   * each object gets its own copy of it.
   */
  public double temperature = 25.5;

  /**
   * Override the behavior of the Object class' toString method.
   */
  public String toString ( ) {
    // Note that it's still possible to get access to the super-class toString 
    // method by calling super.toString()
    return "SimpleObject(" + temperature + "): " + super.toString ( );
  }
}
