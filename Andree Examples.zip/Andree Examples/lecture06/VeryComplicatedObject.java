/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 1, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture06;

/**
 * Empty class that shows that even without any code, there is still at least an
 * implicitly defined empty constructor, that only calls the super constructor.
 * Everything else is inherited from classes higher up in the hierarchy.
 */
public class VeryComplicatedObject extends ComplexObject {

}
