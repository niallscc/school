/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 5, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture08;

import java.awt.Color;

import edu.unm.cs.cs251.andree.spring10.lecture07.Gender;
import edu.unm.cs.cs251.andree.spring10.lecture07.Person;

/**
 * The student class is supposed to show how you can utilize functionality
 * defined in a superclass to your advantage in the subclass.
 */
public class Student extends Person {

  /** Grade point average for this student. */
  private double gpa;

  /** Current major for this student. */
  private String currentMajor;

  /** Classes this student is currently enrolled in. */
  private String[] currentClasses;

  /** How awake the student is. */
  private int levelOfConciousness;

  /**
   * This constructor more or less mirrors what the Person constructor does.
   * Note though, that unless we write a constructor, we won't be able to create
   * an object of this class because there is no parameter-less constructor in
   * the superclass, and the default constructor would only provide a call to
   * the non-existing parameterless constructor, and hence cause a compiler
   * error.
   * @param gender Student's gender
   * @param eyeColor Student's eye color
   * @param age Student's age
   * @param name Student's name
   */
  public Student ( Gender gender, Color eyeColor, int age, String name ) {
    super ( gender, eyeColor, age, name );
    this.levelOfConciousness = 100;
  }

  /**
   * Allows this student to consume some sort of beverages. Note how this method
   * can keep track of the current state of the object, and also allow or deny
   * the student from doing certain things. If the consumption went ok, the
   * state of the object may change.
   * @param substance The substance to consume by drinking.
   */
  public void drink ( String substance ) {
    if ( substance.equals ( "Coffee" ) ) {
      if ( this.levelOfConciousness < 100 ) {
	this.levelOfConciousness++;
      }
    } else if ( substance.equals ( "Beer" ) ) {
      if ( this.ageInYears >= 21 )
	if ( this.levelOfConciousness > 70 )
	  this.levelOfConciousness -= 10;
	else
	  System.err.println ( "Sorry, you've had enough!" );
      else
	System.err.println ( "I'm calling the cops" );
    } else {
      System.err.println ( "You can't drink that!" );
    }
  }

  /**
   * This method was written to show how it's possible for an instance of a
   * class to access private instance variables of another instance of the same
   * class. I.e., this.gpa vs. friend.gpa. It also shows the first mention of
   * polymorphism, where the parameter to this method may end up being either a
   * student or a person, but because person is higher in the hierarchy it can
   * be used to represent either a student or a Person.
   * @param friend The person to interact with
   */
  public void interact ( Person friend ) {
    if ( friend instanceof Student ) {
      if ( this.gpa > ( (Student) friend ).gpa ) {
	System.out.println ( "Ha Ha!" );
      } else {
	System.out.println ( "Get out of here!" );
      }
    } else {
      System.out.println ( "Hello there!" );
    }
  }

  /**
   * @return the currentMajor
   */
  public String getCurrentMajor ( ) {
    return currentMajor;
  }

  /**
   * @param currentMajor the currentMajor to set
   */
  public void setCurrentMajor ( String currentMajor ) {
    if ( currentMajor != null )
      this.currentMajor = currentMajor;
  }

  /**
   * @return the currentClasses
   */
  public String[] getCurrentClasses ( ) {
    return currentClasses;
  }

  /**
   * @param currentClasses the currentClasses to set
   */
  public void setCurrentClasses ( String[] currentClasses ) {
    this.currentClasses = currentClasses;
  }

  /**
   * @return the gpa
   */
  public double getGpa ( ) {
    return gpa;
  }

  public String toString ( ) {
    return "I'm a student in " + currentMajor + "\n" + super.toString ( );
  }

}
