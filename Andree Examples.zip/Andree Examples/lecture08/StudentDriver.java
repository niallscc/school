/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 5, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture08;

import java.awt.Color;

import edu.unm.cs.cs251.andree.spring10.lecture07.Gender;
import edu.unm.cs.cs251.andree.spring10.lecture07.Person;

/**
 * Test program for the student class.
 */
public class StudentDriver {

  public static void main ( String[] args ) {

    // This is ok...
    Student s = new Student ( Gender.MALE, Color.MAGENTA, 22, "Harold" );
    System.out.println ( s );
    // And fairly straight forward to understand
    s.setCurrentMajor ( "Computer Science" );
    System.out.println ( s );

    // This however is usually a little more complicated to understand, but 
    // basically it means that since a student is also a person, we can refer
    // to a student object through a Person variable, but not the other way
    // around.
    Person p = new Student ( Gender.FEMALE, Color.blue, 24, "Jenny" );

  }

}
