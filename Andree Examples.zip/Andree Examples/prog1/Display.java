/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.1 (May 10, 2008)
 * @version 1.2 (Aug 28, 2008)
 * @version 1.3 (Jan 30, 2009)
 * @version 1.4 (Sep 3, 2009)
 * @version 1.5 (Jan 21, 2009)
 */
package edu.unm.cs.cs251.andree.spring10.prog1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * The main Display class for the first assignment in 251.
 */
public class Display {
  /**
   * Special class for drawing dots on a display
   * 
   */
  private class DisplayPanel extends JPanel {
    /**
     * To avoid compiler errors
     */
    private static final long serialVersionUID = 1L;

    /**
     * Default constructor sets up default behavior
     */
    public DisplayPanel ( ) {
      setPreferredSize ( new Dimension ( 400, 400 ) );
      setBackground ( Color.BLACK );
    }

    @Override
    public void paintComponent ( Graphics g ) {
      Graphics2D g2d = (Graphics2D) g;
      g2d.setBackground ( Color.black );
      g2d.clearRect ( 0, 0, getWidth ( ), getHeight ( ) );
      ListIterator<Color> colorListIterator = _colors.subList (
	  _colors.size ( ) - _points.size ( ), _colors.size ( ) )
	  .listIterator ( );
      Point p = null;
      int xOffset = -_pixelSize / 2;
      int yOffset = -_pixelSize / 2;

      synchronized ( _points ) {
	ListIterator<Point> pointIterator = _points.listIterator ( );
	while ( pointIterator.hasNext ( ) ) {
	  if ( colorListIterator.hasNext ( ) )
	    g2d.setColor ( colorListIterator.next ( ) );
	  p = pointIterator.next ( );
	  g2d.fillRect ( p.x + xOffset, p.y + yOffset, _pixelSize, _pixelSize );
	}
      }

      g2d.setColor ( Color.WHITE );
      g2d.drawString ( "Fps: " + _fps, getWidth ( ) - 75, getHeight ( ) - 25 );
    }

  }

  /**
   * Default length of the trace
   */
  private static final int DEFAULT_TRACE_LENGTH = 25;

  /**
   * Default pixel size
   */
  private static final int DEFAULT_PIXEL_SIZE = 5;

  /**
   * To avoid compiler warnings
   */
  private static final long serialVersionUID = 1L;

  /**
   * Maximum delay for the speed slider
   */
  private static final int MAX_DELAY = 500;

  /**
   * List to hold the list of trace points
   */

  private JFrame _mainFrame;

  /**
   * List of points
   */
  private List<Point> _points = null;

  /**
   * List of colors
   */
  private List<Color> _colors = null;

  /**
   * Current trace index
   */
  private int _maxTraceLength = DEFAULT_TRACE_LENGTH;

  /**
   * Delay to use for the update frequency
   */
  private int _updateDelay = MAX_DELAY / 4;

  /**
   * Starting color of the first pixel
   */
  private Color _pixelColor = Color.RED;

  /**
   * Size of each pixel to draw
   */
  private int _pixelSize = DEFAULT_PIXEL_SIZE;

  /**
   * Panel to draw pixels on
   */
  private DisplayPanel _drawPanel;

  // Frames painted per second
  private int _fps = 0;

  // Frames counted so far in this second
  private AtomicInteger _framesPainted = new AtomicInteger ( );

  /**
   * Creates a display with 25 trace pixels, and pixel size 3
   */
  public Display ( ) {
    this ( 25, 3 );
  }

  /**
   * Main constructor for the display
   * @param tracePixels The number of trace pixels to use
   * @param pixelSize The size of each box pixel
   */
  public Display ( int traceLength, int pixelSize ) {

    setTraceLength ( traceLength );

    _mainFrame = new JFrame ( );
    _mainFrame.setSize ( 450, 450 );
    _mainFrame.setTitle ( "CS251 Pixel Tracer" );
    _mainFrame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );

    JPanel control = new JPanel ( );
    control.setPreferredSize ( new Dimension ( 400, 50 ) );

    control.add ( new JLabel ( "Speed:" ) );

    // Create the speed slider to control update frequency
    JSlider speedSlider = new JSlider ( );
    speedSlider.setPreferredSize ( new Dimension ( 75, 20 ) );
    speedSlider.setCursor ( new Cursor ( Cursor.HAND_CURSOR ) );
    speedSlider.setMaximum ( MAX_DELAY );
    speedSlider.setMinimum ( 0 );
    speedSlider.setPaintTicks ( false );
    speedSlider.setValue ( _updateDelay );
    speedSlider.addChangeListener ( new ChangeListener ( ) {
      public void stateChanged ( ChangeEvent e ) {
	JSlider s = (JSlider) e.getSource ( );
	_updateDelay = s.getValue ( );
      }
    } );
    control.add ( speedSlider );

    control.add ( new JLabel ( "Length:" ) );
    JTextField lengthField = new JTextField ( );
    lengthField.setPreferredSize ( new Dimension ( 50, 20 ) );

    lengthField.setText ( "" + _maxTraceLength );
    lengthField.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	JTextField jtf = (JTextField) e.getSource ( );
	int length = _maxTraceLength;
	try {
	  length = Integer.parseInt ( jtf.getText ( ) );
	  setTraceLength ( length );
	  generateColorSpectrum ( );
	} catch ( NumberFormatException ex ) {
	  jtf.setText ( "" + length );
	}
      }
    } );
    control.add ( lengthField );

    // Create a button that allows user to pick a new color to draw with
    final JButton colorButton = new JButton ( "Color" );
    colorButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent arg0 ) {
	_pixelColor = JColorChooser.showDialog ( colorButton, "Pick a color",
	    _pixelColor );
	generateColorSpectrum ( );
      }
    } );
    control.add ( colorButton );

    // Create the quit button so we can exit
    JButton quitButton = new JButton ( "Quit" );
    quitButton.addActionListener ( new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	System.exit ( 0 );
      }
    } );
    control.add ( quitButton );

    // Add the control panel to the main frame
    _mainFrame.add ( control, BorderLayout.SOUTH );

    // Create the JPanel that we will draw the pixels on
    _drawPanel = new DisplayPanel ( );
    _mainFrame.add ( _drawPanel, BorderLayout.CENTER );

    if ( pixelSize < 1 )
      _pixelSize = 1;
    else
      _pixelSize = pixelSize;

    // Make sure the components are laid out properly and show the frame
    // at the center of the screen
    _mainFrame.pack ( );
    _mainFrame.setLocationRelativeTo ( null );
    _mainFrame.setVisible ( true );

    Timer t = new Timer ( );
    t.schedule ( new TimerTask ( ) {
      @Override
      public void run ( ) {
	// Calculate fps
	_fps = _framesPainted.get ( );
	_framesPainted.set ( 0 );
      }

    }, 1000, 1000 );

  }

  /**
   * After updates of the color or size of spectrum, this method is called to
   * create the new set of colors to use when drawing
   */
  private void generateColorSpectrum ( ) {

    // Generate new color spectrum
    _colors = Collections.synchronizedList ( new LinkedList<Color> ( ) );
    float alphaDiff = 1.0f / _maxTraceLength;
    float red = _pixelColor.getRed ( ) / 255f;
    float green = _pixelColor.getGreen ( ) / 255f;
    float blue = _pixelColor.getBlue ( ) / 255f;
    for ( int i = _maxTraceLength - 1; i >= 0; i-- )
      _colors.add ( new Color ( red, green, blue, 1.0f - alphaDiff * i ) );
  }

  /**
   * Update the length of the pixel trace
   * @param length length of the trace, > 1
   */
  private void setTraceLength ( int length ) {

    // Set the new trace length
    _maxTraceLength = length <= 1 ? 1 : length;

    generateColorSpectrum ( );
    if ( _points == null ) {
      _points = Collections.synchronizedList ( new LinkedList<Point> ( ) );
    } else if ( _maxTraceLength < _points.size ( ) ) {
      _points = Collections.synchronizedList ( _points.subList ( _points
	  .size ( )
	  - _maxTraceLength, _points.size ( ) ) );
    }
  }

  /**
   * Draw the most recent pixel at position
   * @param x
   * @param y
   */
  public void drawNextPixel ( int x, int y ) {

    if ( _points.size ( ) < _maxTraceLength )
      _points.add ( new Point ( x, y ) );
    else {
      Point p = _points.remove ( 0 );
      p.setLocation ( x, y );
      _points.add ( p );
    }

    _drawPanel.repaint ( );
    _framesPainted.incrementAndGet ( );

    // Sleep for delay milliseconds so that we can control update speed
    try {
      Thread.sleep ( MAX_DELAY - _updateDelay, 125 );
    } catch ( InterruptedException e ) {
      // Got woken up, no need to worry
    }

  }

  /**
   * Return the width of the black part of the display
   */
  public int getHeight ( ) {
    return _drawPanel.getHeight ( );
  }

  /**
   * Return the height of the black part of the display
   */
  public int getWidth ( ) {
    return _drawPanel.getWidth ( );
  }

  @Override
  public String toString ( ) {
    return "Andree's Display";
  }
}
