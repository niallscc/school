/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 14, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.prog4.shapes;

import edu.unm.cs.cs251.andree.spring10.prog2.Block;

/**
 * 
 */
public class ZShape extends TetrisPiece2D {
  public ZShape() {
    Block.Type p = Block.Type.PRESENT;
    Block.Type m = Block.Type.MISSING;
    Block[][] shape = { 
	{ new Block ( m ), new Block ( p ) }, 
	{ new Block ( p ), new Block ( p ) },
	{ new Block ( p ), new Block ( m ) }
    };
    _shape = shape;
  }
}

