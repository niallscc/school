/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.prog4.shapes;

import edu.unm.cs.cs251.andree.spring10.prog2.Block;
import edu.unm.cs.cs251.andree.spring10.prog2.Object2D;
import edu.unm.cs.cs251.andree.spring10.prog2.Rotate2D;

/**
 * A 2D Tetris piece upper level class. The other underlying classes will each
 * represent a Tetris piece.
 */
public abstract class TetrisPiece2D implements Object2D {

  /**
   * This objects orientation, when first created always at 0 degrees.
   */
  protected double orientation = 0.0;

  /**
   * Internal representation for the shape
   */
  protected Block[][] _shape;

  /**
   * @see Object2D#getDimension()
   */
  public Dimension2D getDimension ( ) {
    return new Dimension2D ( _shape.length, _shape[0].length );
  }

  /**
   * @see Rotate2D#rotate(Rotate2D.Direction2D)
   */
  public void rotate ( Direction2D dir ) {
    if ( dir == Direction2D.CW ) {
      final Block[][] grid = new Block[_shape[0].length][_shape.length];
      for ( int row = 0; row < _shape[0].length; row++ )
	for ( int col = 0; col < _shape.length; col++ )
	  grid[row][col] = _shape[_shape.length - 1 - col][row];
      _shape = grid;
      orientation = ( orientation + 90 ) % 360;
    } else
      for ( int i = 0; i < 3; i++ )
	rotate ( Direction2D.CW );
  }

  /**
   * @see Object#toString()
   */
  @Override
  public String toString ( ) {
    final StringBuffer s = new StringBuffer ( );
    for ( int row = 0; row < _shape.length; row++ ) {
      for ( int col = 0; col < _shape[row].length; col++ )
	s.append ( _shape[row][col] );
      s.append ( row != _shape.length - 1 ? "\n" : "" );
    }
    return s.toString ( );
  }

  /**
   * @see edu.unm.cs.cs251.andree.spring10.prog2.Rotate2D#getOrientation()
   */
  public int getOrientation ( ) {
    return (int) orientation;
  }

  /**
   * Return a copy of the internal state of this object.
   * @return A copy of the data array for this object
   */
  public Block[][] getBlockArray ( ) {
    return _shape.clone ( );
  }

}
