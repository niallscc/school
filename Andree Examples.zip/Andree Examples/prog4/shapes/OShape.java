/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Feb 12, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.prog4.shapes;

import edu.unm.cs.cs251.andree.spring10.prog2.Block;
import edu.unm.cs.cs251.andree.spring10.prog2.Block.Type;

/**
 * 
 */
public class OShape extends TetrisPiece2D {

  public OShape ( ) {
    Type t = Block.Type.PRESENT;
    Block[][] shape = { 
	{ new Block ( t ), new Block ( t ) },
	{ new Block ( t ), new Block ( t ) } 
    };
    _shape = shape;
  }
}
