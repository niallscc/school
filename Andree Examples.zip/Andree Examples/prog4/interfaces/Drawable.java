/**
 * @author Andree Jacobson ( andree@unm.edu )
 * @version 1.0 (Feb 21, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.prog4.interfaces;

import java.awt.Graphics;

/**
 * This interface defines methods required for an object to draw itself on some
 * graphics contexts.
 */
public interface Drawable {

  /**
   * Draws implementing classes on the provided graphics context
   * @param g Graphics context to draw this object on
   * @param x offset in block units of the upper left block of this object
   * @param y offset in block units of the upper left block of this object
   */
  public void draw ( Graphics g, int x, int y);

}
