/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 14, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture34;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * 
 */
public class UsingScrollbars extends SimpleGUI {
  private static final long serialVersionUID = 1L;

  public static BufferedImage superNova;
  static {
    try {
      superNova = ImageIO.read ( new File ( UsingScrollbars.class.getResource (
	  "Keplers_supernova.jpg" ).getFile ( ) ) );
    } catch ( IOException e ) {
      superNova = null;
      System.err.println ( "No pic!" );
      System.exit ( 1 );
    }
  }

  private class MyPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    public MyPanel ( ) {
      Dimension d = new Dimension ( (int) ( superNova.getWidth ( ) * scale ),
	  (int) ( superNova.getHeight ( ) * scale ) );
      setPreferredSize ( d );
    }

    public void paintComponent ( Graphics g ) {
      super.paintComponent ( g );
      AffineTransform at = new AffineTransform ( );
      at.scale ( scale, scale );
      ( (Graphics2D) g ).drawRenderedImage ( superNova, at );
    }
  }

  private double scale = 25 / 100.0;

  public UsingScrollbars ( ) {
    super ( "My Scrolling GUI" );

    final JPanel p = new MyPanel ( );
    final JScrollPane jsp = new JScrollPane ( p );
    
    this.add ( jsp, BorderLayout.CENTER );
    JPanel control = new JPanel ( );
    this.add ( control, BorderLayout.SOUTH );
    JSlider slider = new JSlider ( );
    slider.setMinimum ( 1 );
    slider.setValue ( (int) ( scale * 100 ) );
    slider.setMaximum ( 100 );
    slider.setPreferredSize ( new Dimension ( 600, 30 ) );
    control.add ( slider );
    slider.addChangeListener ( new ChangeListener ( ) {

      @Override
      public void stateChanged ( ChangeEvent e ) {
	int newValue = ( (JSlider) e.getSource ( ) ).getValue ( );
	scale = newValue / 100.0;
	Dimension d = new Dimension ( (int) ( superNova.getWidth ( ) * scale ),
	    (int) ( superNova.getHeight ( ) * scale ) );
	p.setPreferredSize ( d );
	jsp.getViewport ( ).revalidate ( );
	p.repaint ( );
      }
    } );
  }

  public static void main ( String[] args ) {
    new UsingScrollbars ( ).setVisible ( true );
  }

}
