/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 19, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture36;

import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 
 */
public class TestSockets {

  public static void main ( String[] args ) throws IOException {
    new Thread ( new Runnable ( ) {
      public void run ( ) {
	try {
	  System.out.println ( "Server started!" );
	  final ServerSocket ss = new ServerSocket ( 12345 );
	  Socket incoming = ss.accept ( );
	  System.out.println ( "Connected!" );
	  ObjectOutputStream oos = new ObjectOutputStream ( incoming
	      .getOutputStream ( ) );
	  Rectangle2D.Double r2d = new Rectangle2D.Double ( 100, 100, 250, 500 );
	  oos.writeObject ( r2d );
	  oos.close ( );
	} catch ( IOException e ) {
	  e.printStackTrace ( );
	}
      }
    } ).start ( );

    try {
      Thread.sleep ( 2000 );
    } catch ( Exception e ) {
    }
    Socket s = new Socket ( "127.0.0.1", 12345 );
    System.out.println ( "Client connected" );
    ObjectInputStream ois = new ObjectInputStream ( s.getInputStream ( ) );
    try {
      Object o = ois.readObject ( );
      System.out.println ( o );
    } catch ( ClassNotFoundException e ) {
      e.printStackTrace ( );
    }
    ois.close ( );

  }

}
