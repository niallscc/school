/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Dec 7, 2009)
 */
package edu.unm.cs.cs251.andree.spring10.lecture36;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 * Class to show a possibility to travel along an arbitrary path.
 */
public class TravelByPath extends JFrame {

  private class TravelPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    ArrayList<Traveller> travellerList = new ArrayList<Traveller> ( );

    public void addTraveller ( Traveller t ) {
      travellerList.add ( t );
    }

    @Override
    public void paintComponent ( Graphics g ) {
      final Graphics2D g2d = (Graphics2D) g;
      g2d.setColor ( Color.white );
      g2d.fillRect ( 0, 0, getWidth ( ), getHeight ( ) );
      g2d.setColor ( Color.RED );
      g2d.draw ( path );
      for ( final Traveller t : travellerList )
	t.paintMe ( g2d );
    }
  }

  private static final long serialVersionUID = 1L;

  private final Path2D path;

  private TravelPanel panel;

  public TravelByPath ( ) {
    this.setSize ( 800, 600 );
    this.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
    this.setLocationRelativeTo ( null );

    path = new Path2D.Double ( );
    path.append ( new Ellipse2D.Double(50, 50, 700, 500), false );
//    path.append ( new QuadCurve2D.Double ( 50, 50, 750, 400, 400, 500 ), false );
//    path.append ( new QuadCurve2D.Double ( 400, 500, 50, 600, 750, 50 ), false );
//    path.quadTo ( 0, 0, 400, 300 );
//    path.lineTo ( 50, 500 );
//    path.lineTo ( 500, 500 );
//    path.lineTo ( 500, 200 );

    this.add ( panel = new TravelPanel ( ), BorderLayout.CENTER );
    this.setVisible ( true );
  }

  public void startAnimation ( ) {
    final Traveller t = new Traveller ( path );
    panel.addTraveller ( t );
    final Timer timer = new Timer ( 10, new ActionListener ( ) {
      public void actionPerformed ( ActionEvent e ) {
	t.updateLocation ( );
	panel.repaint ( );
	if ( t.arrived ( ) )
	  ( (Timer) e.getSource ( ) ).stop ( );
      }
    } );
    timer.start ( );
  }

  public static void main ( String[] args ) {
    final TravelByPath tp = new TravelByPath ( );

    // Make sure animation doesn't start until gui is ready.
    SwingUtilities.invokeLater ( new Runnable ( ) {
      public void run ( ) {
	tp.startAnimation ( );
      }
    } );
  }
}

class Traveller {
  private Path2D myPath;
  private PathIterator myIterator;

  private Point2D.Double myPoint = new Point2D.Double ( );

  final private Ellipse2D.Double myShape = new Ellipse2D.Double ( );

  private int updateNumber = 0;

  private final boolean onLine = false; // Keeps track if we're on a straight line

  private final double moveDelta = 1.0;

  public Traveller ( Path2D path ) {
    setPath ( path );
  }

  public boolean arrived ( ) {
    return myIterator != null ? myIterator.isDone ( ) : true;
  }

  public void paintMe ( Graphics g ) {
    updateNumber++;
    final Graphics2D g2d = (Graphics2D) g;
    if ( myPoint != null ) {
      g2d.setColor ( Color.BLUE );
      myShape.setFrameFromCenter ( myPoint, new Point2D.Double (
	  myPoint.x + 25, myPoint.y + 25 ) );
      g2d.draw ( myShape );
      g2d.drawString ( "" + updateNumber, 25, 550 );
    }
  }

  public void setPath ( Path2D path ) {
    myPath = path;
    myIterator = myPath.getPathIterator ( null, .5f );
    updateLocation ( );
  }

  public void updateLocation ( ) {
    if ( myIterator != null && !myIterator.isDone ( ) ) {
      final double[] coords = new double[6];
      final int segType = myIterator.currentSegment ( coords );
      switch ( segType ) {
	case PathIterator.SEG_LINETO:
	  // onLine = true;
	  break;
	case PathIterator.SEG_MOVETO:
	  myPoint.setLocation ( coords[0], coords[1] );
	  break;
	case PathIterator.SEG_CLOSE:
	  myPoint = null;
      }

      if ( myPoint != null ) {
	final Point2D.Double newPoint = new Point2D.Double ( coords[0],
	    coords[1] );

	// If more than one pixel traverse this line by hand
	if ( myPoint.distance ( coords[0], coords[1] ) > 1.0 ) {

	  final double angle = getAngle ( myPoint, newPoint );
	  myPoint.x += moveDelta * Math.cos ( angle );
	  myPoint.y += moveDelta * Math.sin ( angle );
	} else {
	  myPoint.setLocation ( newPoint );
	  if ( !myIterator.isDone ( ) ) {
	    myIterator.next ( );
	  } else
	    myIterator = null;
	}

      }
    }
  }

  /* Return the angle between these two coordinates, not freed */
  public static double getAngle ( Point2D p1, Point2D p2 ) {
    final double a = p2.getY ( ) - p1.getY ( );
    final double b = p2.getX ( ) - p1.getX ( );
    double alpha = 0;
    final double c = p1.distance ( p2 );
    /* Determine the correct angle between coordinates */
    if ( c != 0 )
      alpha = ( b < 0 ) ? Math.PI - Math.asin ( a / c ) : Math.asin ( a / c );
    if ( alpha < 0 )
      alpha = 2 * Math.PI + alpha;
    return alpha;
  }
}
