/**
 * @author Andree Jacobson (andree@unm.edu)
 * @version 1.0 (Apr 19, 2010)
 */
package edu.unm.cs.cs251.andree.spring10.lecture36;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Robot;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;

import edu.unm.cs.cs251.andree.spring10.lecture14.SimpleGUI;

/**
 * 
 */
public class ColorPanel extends SimpleGUI {

  private static final long serialVersionUID = 1L;
  private JPanel control;
  private ColorPane cp;

  private class ColorPane extends JPanel implements MouseMotionListener {

    public ColorPane ( ) {
      addMouseMotionListener ( this );
    }

    private static final long serialVersionUID = 1L;

    public void paintComponent ( Graphics g ) {
      Color c = null;
      for ( int y = 0; y < 256; y++ ) {
	for ( int x = 0; x < 256; x++ ) {
	  c = new Color ( x, y, 255 );
	  g.setColor ( c );
	  g.drawLine ( x, y, x, y );
	}
      }
    }

    @Override
    public void mouseDragged ( MouseEvent e ) {
    }

    /**
     * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
     */
    @Override
    public void mouseMoved ( MouseEvent e ) {
      Point p = e.getPoint ( );
      try {
	Robot r = new Robot ( );
	Color c = r.getPixelColor ( ColorPanel.this.getX ( ) + p.x,
	    ColorPanel.this.getY ( ) + p.y );
	colorLabel.setText ( "Color: " + c.getRed ( ) + "," + c.getGreen ( )
	    + "," + c.getBlue ( ) );
      } catch ( AWTException e1 ) {
	System.err.println ( "Can't create robot" );
      }

    }
  }

  private JLabel colorLabel = new JLabel ( );

  public ColorPanel ( ) {
    super ( "The Color Panel" );
    this.add ( cp = new ColorPane ( ), BorderLayout.CENTER );
    cp.setPreferredSize ( new Dimension ( 256, 256 ) );
    control = new JPanel ( );
    colorLabel.setText ( "Color: " );
    control.add ( colorLabel );
    this.add ( control, BorderLayout.SOUTH );
    this.pack ( );
    this.setLocationRelativeTo ( null );
  }

  public static void main ( String[] args ) {
    new ColorPanel ( ).setVisible ( true );
  }

}
